import React, { useState } from "react";
import { 
  ArrowLeft, 
  PlayCircle, 
  FileText, 
  Download, 
  Lock, 
  CheckCircle2, 
  Star, 
  Layers, 
  ChevronRight, 
  ChevronDown, 
  BookOpen, 
  Clock, 
  Award, 
  Sparkles,
  Maximize2,
  Volume2,
  RotateCcw,
  Share2,
  MessageSquare,
  ShieldCheck,
  Building2,
  ChevronLeft
} from "lucide-react";
import { api } from "../../services/api";

export const CourseLearningStudio = ({ course, currentUser, onBack, onEnrollSuccess }) => {
  const subjects = course?.subjects || [];
  
  // Default to first subject, first module, first material
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || "");
  const [selectedModuleId, setSelectedModuleId] = useState(subjects[0]?.modules?.[0]?.id || "");
  const [selectedMaterial, setSelectedMaterial] = useState(
    subjects[0]?.modules?.[0]?.materials?.[0] || {
      id: "default_mat",
      title: "Lecture 1: Primitive Equations in Sigma & Pressure Coordinates",
      type: "video",
      duration: "45 mins",
      allowDownload: false,
      url: "https://www.youtube.com/embed/dQw4w9WgXcQ"
    }
  );

  const [activeBottomTab, setActiveBottomTab] = useState("overview"); // "overview" | "notes" | "feedback" | "qa"
  const [completedMaterials, setCompletedMaterials] = useState({ [selectedMaterial.id]: true });
  const [currentSlidePage, setCurrentSlidePage] = useState(1);
  const [expandedSubjects, setExpandedSubjects] = useState({ [subjects[0]?.id]: true });

  // Feedback State
  const [feedbackForm, setFeedbackForm] = useState({
    trainerRating: 5,
    contentRating: 5,
    relevanceRating: 5,
    comment: ""
  });
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  const toggleSubjectExpand = (subId) => {
    setExpandedSubjects(prev => ({ ...prev, [subId]: !prev[subId] }));
  };

  const handleSelectMaterial = (subId, modId, mat) => {
    setSelectedSubjectId(subId);
    setSelectedModuleId(modId);
    setSelectedMaterial(mat);
    setCurrentSlidePage(1);
    setCompletedMaterials(prev => ({ ...prev, [mat.id]: true }));
  };

  const handleSendFeedback = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        courseId: course.id,
        traineeId: currentUser?.id || "u_trainee_1",
        traineeName: currentUser?.name || "Rahul Sharma",
        ...feedbackForm
      };
      const res = await api.submitFeedback(payload);
      if (res.success) {
        setFeedbackSubmitted(true);
      }
    } catch (err) {
      alert("Feedback submission failed: " + err.message);
    }
  };

  // Calculate total materials count and progress
  let totalMaterials = 0;
  subjects.forEach(s => s.modules?.forEach(m => totalMaterials += (m.materials?.length || 0)));
  const completedCount = Object.keys(completedMaterials).length;
  const progressPct = totalMaterials > 0 ? Math.min(Math.round((completedCount / totalMaterials) * 100), 100) : 50;

  return (
    <div className="flex flex-col h-full bg-[#f8fafc] overflow-hidden select-none font-sans">
      {/* Studio Header Bar */}
      <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 shadow-sm z-20">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
            <span>Back to Courses</span>
          </button>

          <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>

          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-[#0a2558] text-white">
                {course.code}
              </span>
              <h1 className="font-bold text-slate-900 text-sm truncate max-w-md">
                {course.title}
              </h1>
            </div>
          </div>
        </div>

        {/* Right Progress & Status */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex flex-col items-end">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">Completion Progress:</span>
              <span className="font-bold text-[#0a2558]">{progressPct}%</span>
            </div>
            <div className="w-36 h-2 bg-slate-100 rounded-full overflow-hidden mt-1 border border-slate-200">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              ></div>
            </div>
          </div>

          <button
            onClick={() => setActiveBottomTab("feedback")}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span>Rate Course</span>
          </button>
        </div>
      </header>

      {/* Main Studio Viewport (2 Columns: Left Curriculum Navigator, Right Material Stage) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left: Interactive Curriculum Navigator */}
        <div className="w-full lg:w-80 bg-white border-r border-slate-200 flex flex-col shrink-0 overflow-y-auto shadow-sm">
          <div className="p-4 border-b border-slate-100 bg-slate-50/70">
            <h2 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#0a2558]" />
              <span>Curriculum & Learning Content</span>
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {subjects.length} Subjects • {totalMaterials} Materials
            </p>
          </div>

          {/* Subjects Accordion */}
          <div className="p-3 space-y-3">
            {subjects.map((subject, sIdx) => {
              const isExpanded = !!expandedSubjects[subject.id];
              return (
                <div key={subject.id} className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-sm">
                  {/* Subject Title Bar */}
                  <button
                    onClick={() => toggleSubjectExpand(subject.id)}
                    className="w-full p-3.5 bg-slate-50 hover:bg-slate-100/80 flex items-center justify-between text-left transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-[#0a2558] text-white flex items-center justify-center font-bold text-[10px]">
                        S{sIdx + 1}
                      </div>
                      <span className="font-bold text-slate-800 text-xs line-clamp-1">{subject.name}</span>
                    </div>
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>

                  {/* Modules & Materials list */}
                  {isExpanded && (
                    <div className="p-2 space-y-2 bg-white">
                      {subject.modules && subject.modules.map(mod => (
                        <div key={mod.id} className="p-2 bg-slate-50/60 rounded-xl">
                          <div className="flex items-center justify-between px-1 mb-1.5">
                            <span className="font-semibold text-slate-700 text-[11px]">{mod.title}</span>
                            <span className="text-[10px] text-slate-400">{mod.duration}</span>
                          </div>

                          <div className="space-y-1">
                            {mod.materials && mod.materials.map(mat => {
                              const isActive = selectedMaterial?.id === mat.id;
                              const isDone = !!completedMaterials[mat.id];

                              return (
                                <button
                                  key={mat.id}
                                  onClick={() => handleSelectMaterial(subject.id, mod.id, mat)}
                                  className={`w-full p-2 rounded-xl text-left flex items-center justify-between gap-2 transition-all text-xs ${
                                    isActive
                                      ? "bg-[#0a2558] text-white font-bold shadow-md transform scale-[1.01]"
                                      : "hover:bg-slate-100 text-slate-700 font-medium"
                                  }`}
                                >
                                  <div className="flex items-center gap-2 truncate">
                                    {mat.type === "video" ? (
                                      <PlayCircle className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-red-400" : "text-red-500"}`} />
                                    ) : mat.type === "presentation" ? (
                                      <Layers className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-yellow-300" : "text-amber-500"}`} />
                                    ) : (
                                      <FileText className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-blue-300" : "text-blue-500"}`} />
                                    )}
                                    <span className="truncate">{mat.title}</span>
                                  </div>

                                  <div className="flex items-center gap-1.5 shrink-0">
                                    {mat.allowDownload ? (
                                      <Download className={`w-3 h-3 ${isActive ? "text-blue-200" : "text-slate-400"}`} />
                                    ) : (
                                      <Lock className={`w-3 h-3 ${isActive ? "text-amber-300" : "text-slate-400"}`} />
                                    )}
                                    {isDone && (
                                      <CheckCircle2 className={`w-3.5 h-3.5 ${isActive ? "text-emerald-400" : "text-emerald-600"}`} />
                                    )}
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Immersive Reading & Viewing Stage */}
        <div className="flex-1 flex flex-col bg-[#f1f5f9] overflow-y-auto">
          {/* Top Stage Action Banner */}
          <div className="bg-white border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shrink-0">
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-900">
                  {selectedMaterial?.type.toUpperCase()} CONTENT
                </span>
                {selectedMaterial?.allowDownload ? (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    <Download className="w-3 h-3" /> Download Enabled
                  </span>
                ) : (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
                    <Lock className="w-3 h-3" /> In-Portal Protected View Only
                  </span>
                )}
              </div>
              <h2 className="text-base font-bold text-slate-900 leading-snug">
                {selectedMaterial?.title}
              </h2>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              {selectedMaterial?.allowDownload ? (
                <button
                  onClick={() => alert(`Downloading resource: ${selectedMaterial?.title}`)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl text-xs shadow-md transition-transform hover:scale-105"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Resource</span>
                </button>
              ) : (
                <div className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-100 border border-slate-200 text-slate-500 rounded-xl text-xs font-semibold">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Trainer Protected (No Export)</span>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Material Viewer Body */}
          <div className="p-6 flex-1">
            {/* 1. VIDEO LECTURE STAGE */}
            {selectedMaterial?.type === "video" && (
              <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 text-white max-w-5xl mx-auto">
                <div className="aspect-video w-full bg-black flex items-center justify-center relative">
                  <iframe
                    className="w-full h-full"
                    src={selectedMaterial.url || "https://www.youtube.com/embed/dQw4w9WgXcQ"}
                    title={selectedMaterial.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="p-5 bg-slate-900/95 flex items-center justify-between border-t border-white/10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center font-bold text-white shadow-lg">
                      🎬
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">{selectedMaterial.title}</h3>
                      <p className="text-xs text-slate-400">Duration: {selectedMaterial.duration || "45 mins"} • High Definition Masterclass</p>
                    </div>
                  </div>

                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Tracked & Recorded
                  </span>
                </div>
              </div>
            )}

            {/* 2. PRESENTATION / SLIDE DECK STAGE */}
            {selectedMaterial?.type === "presentation" && (
              <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden max-w-5xl mx-auto flex flex-col">
                {/* Slide Toolbar */}
                <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-xs">Interactive Meteorological Slide Deck</span>
                  </div>

                  {/* Slide Navigation */}
                  <div className="flex items-center gap-3">
                    <button
                      disabled={currentSlidePage <= 1}
                      onClick={() => setCurrentSlidePage(prev => Math.max(1, prev - 1))}
                      className="p-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-40 rounded-lg text-white"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-bold text-slate-200 font-mono">
                      Slide {currentSlidePage} of {selectedMaterial.pages || 34}
                    </span>
                    <button
                      disabled={currentSlidePage >= (selectedMaterial.pages || 34)}
                      onClick={() => setCurrentSlidePage(prev => Math.min(selectedMaterial.pages || 34, prev + 1))}
                      className="p-1.5 bg-white/10 hover:bg-white/20 disabled:opacity-40 rounded-lg text-white"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* High Definition Slide Visual Canvas */}
                <div className="p-8 bg-gradient-to-br from-slate-900 via-blue-950 to-[#0a2558] text-white min-h-[420px] flex flex-col justify-between relative overflow-hidden">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-blue-300" />
                      <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
                        IMD Directorate of NWP & Radar Operations
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">SLIDE_REF_#0{currentSlidePage}</span>
                  </div>

                  <div className="py-6 space-y-4 max-w-2xl">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-400 text-slate-900">
                      Module Section {currentSlidePage}
                    </span>
                    <h2 className="text-2xl font-black tracking-tight text-white">
                      Primitive Equation Coordinate Transformations & Hydrostatic Approximation
                    </h2>
                    <p className="text-xs text-blue-100/90 leading-relaxed">
                      In operational numerical modeling across complex Indian topography (Himalayan orography & Western Ghats), terrain-following sigma coordinates sigma = (p - pt)/(ps - pt) ensure smooth lower boundary representation without stepped grid reflections.
                    </p>

                    <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 text-xs font-mono text-blue-200">
                      <code>du/dt + u(du/dx) + v(du/dy) + sigma_dot(du/d_sigma) - fv = -dPhi/dx - sigma*alpha*(dp_s/dx)</code>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-blue-200/70">
                    <span>Trainer: Dr. Amit Sengupta</span>
                    <span>Confidential • MoES Operational Capacity Series</span>
                  </div>
                </div>
              </div>
            )}

            {/* 3. SCIENTIFIC STUDY NOTES / PDF STAGE */}
            {selectedMaterial?.type === "pdf" && (
              <div className="bg-white rounded-3xl shadow-xl border border-slate-200 p-8 max-w-5xl mx-auto space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">{selectedMaterial.title}</h3>
                      <p className="text-xs text-slate-500">Official IMD Technical Reference Document • Size: {selectedMaterial.size || "3.5 MB"}</p>
                    </div>
                  </div>

                  {selectedMaterial.allowDownload && (
                    <button
                      onClick={() => alert(`Downloading: ${selectedMaterial.title}`)}
                      className="flex items-center gap-2 px-4 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white rounded-xl text-xs font-bold shadow-md"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download PDF Notes</span>
                    </button>
                  )}
                </div>

                {/* Structured Rich Document Content */}
                <div className="prose prose-slate max-w-none text-xs leading-relaxed space-y-4 text-slate-700">
                  <div className="p-4 bg-blue-50/70 rounded-2xl border border-blue-200 text-blue-950 font-medium">
                    <h4 className="font-bold text-sm mb-1 text-[#0a2558]">Executive Summary for Shift Forecasters:</h4>
                    This technical guide establishes the mathematical basis for planetary boundary layer (PBL) parameterization in high-resolution regional weather forecast domains over the Indian subcontinent.
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 pt-2 border-b border-slate-100 pb-1">
                    1. Governing Planetary Boundary Layer Equations
                  </h3>
                  <p>
                    The turbulent momentum flux divergence in the atmospheric surface layer is parameterized via eddy diffusivity (Km) formulations:
                  </p>
                  <div className="p-3.5 bg-slate-100 rounded-xl font-mono text-slate-900 text-xs border border-slate-200">
                    tau_x = rho * Km * (du/dz), tau_y = rho * Km * (dv/dz)
                  </div>
                  <p>
                    Where Km = l^2 * |dV/dz| * f(Ri), and Ri is the gradient Richardson number denoting dynamic stability versus buoyant production of convective turbulence.
                  </p>

                  <h3 className="text-sm font-bold text-slate-900 pt-2 border-b border-slate-100 pb-1">
                    2. Dual-Polarization Radar Ingestion Guidelines
                  </h3>
                  <p>
                    When Doppler Radar reflectivity moments (ZH, ZDR, KDP, RhoHV) are ingested into the 3D-Var variational assimilation framework, hydrometeor classification weights must filter out anomalous ground clutter and sea spray returns along coastal radar stations (Chennai, Machilipatnam, Visakhapatnam, Gopalpur).
                  </p>
                </div>
              </div>
            )}

            {/* Bottom Panel (Overview, Trainer Bio, Feedback & Rating) */}
            <div className="mt-8 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm max-w-5xl mx-auto space-y-4">
              <div className="flex border-b border-slate-200 text-xs font-bold">
                <button
                  onClick={() => setActiveBottomTab("overview")}
                  className={`pb-3 px-4 border-b-2 transition-colors ${
                    activeBottomTab === "overview" ? "border-[#0a2558] text-[#0a2558]" : "border-transparent text-slate-400"
                  }`}
                >
                  📖 Course & Module Overview
                </button>
                <button
                  onClick={() => setActiveBottomTab("feedback")}
                  className={`pb-3 px-4 border-b-2 transition-colors ${
                    activeBottomTab === "feedback" ? "border-[#0a2558] text-[#0a2558]" : "border-transparent text-slate-400"
                  }`}
                >
                  ⭐ Course & Trainer Feedback
                </button>
              </div>

              {/* Bottom Tab 1: Overview */}
              {activeBottomTab === "overview" && (
                <div className="text-xs text-slate-600 space-y-2 py-2">
                  <p className="leading-relaxed">{course.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="text-slate-400 font-semibold block text-[10px] uppercase">Lead Instructor</span>
                      <b className="text-slate-800 text-xs">{course.leadTrainerName}</b>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="text-slate-400 font-semibold block text-[10px] uppercase">Department</span>
                      <b className="text-slate-800 text-xs">{course.department}</b>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="text-slate-400 font-semibold block text-[10px] uppercase">Credit Hours</span>
                      <b className="text-slate-800 text-xs">{course.creditHours} MoES Credits</b>
                    </div>
                  </div>
                </div>
              )}

              {/* Bottom Tab 2: Feedback & Rating Form */}
              {activeBottomTab === "feedback" && (
                <div className="py-2 text-xs">
                  {feedbackSubmitted ? (
                    <div className="p-6 text-center bg-emerald-50 rounded-2xl border border-emerald-200">
                      <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-1" />
                      <h4 className="font-bold text-emerald-900 text-sm">Feedback Successfully Recorded!</h4>
                      <p className="text-emerald-700 text-[11px]">
                        Your review will assist the Ministry of Earth Sciences in continuous curriculum improvement.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleSendFeedback} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                          <label className="block font-semibold text-slate-700 mb-1">Trainer Clarity</label>
                          <select
                            value={feedbackForm.trainerRating}
                            onChange={(e) => setFeedbackForm({ ...feedbackForm, trainerRating: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded font-bold text-center"
                          >
                            <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                            <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                            <option value={3}>⭐⭐⭐ (3/5)</option>
                          </select>
                        </div>

                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                          <label className="block font-semibold text-slate-700 mb-1">Content Depth</label>
                          <select
                            value={feedbackForm.contentRating}
                            onChange={(e) => setFeedbackForm({ ...feedbackForm, contentRating: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded font-bold text-center"
                          >
                            <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                            <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                            <option value={3}>⭐⭐⭐ (3/5)</option>
                          </select>
                        </div>

                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                          <label className="block font-semibold text-slate-700 mb-1">Forecasting Utility</label>
                          <select
                            value={feedbackForm.relevanceRating}
                            onChange={(e) => setFeedbackForm({ ...feedbackForm, relevanceRating: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded font-bold text-center"
                          >
                            <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                            <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                            <option value={3}>⭐⭐⭐ (3/5)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Detailed Observations</label>
                        <textarea
                          rows={2}
                          required
                          value={feedbackForm.comment}
                          onChange={(e) => setFeedbackForm({ ...feedbackForm, comment: e.target.value })}
                          placeholder="How did this module assist your operational weather shift analysis?"
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                        />
                      </div>

                      <div className="text-right">
                        <button
                          type="submit"
                          className="px-5 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl shadow-md"
                        >
                          Submit Course Feedback
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
