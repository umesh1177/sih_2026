// AI Question Generator for Capacity Connect MoES/IMD Portal
import { v4 as uuidv4 } from "uuid";

// Domain Knowledge Bank for instant intelligent question synthesis
const domainKnowledge = {
  nwp: [
    {
      q: "Which thermodynamic variable is conserved in both dry and moist adiabatic processes without precipitation in NWP models?",
      options: ["Equivalent Potential Temperature (Theta-e)", "Virtual Temperature (Tv)", "Dew Point Temperature (Td)", "Dry Static Energy (s)"],
      correct: 0,
      marks: 3,
      difficulty: "Hard",
      explanation: "Equivalent potential temperature (Theta-e) is conserved during both dry and reversible moist pseudoadiabatic ascents."
    },
    {
      q: "What is the primary function of the Arakawa C-grid staggering utilized in the WRF model?",
      options: ["Staggering velocity components (u, v) at cell faces and mass variables (T, P) at cell centers to optimize gravity wave propagation", "Placing all variables at the cell vertex", "Using hexagonal spherical harmonics", "Eliminating vertical advection"],
      correct: 0,
      marks: 2,
      difficulty: "Medium",
      explanation: "Arakawa C-grid provides the best dispersion properties for high-resolution gravity waves and boundary layer turbulence."
    },
    {
      q: "In 4D-Var Data Assimilation, what is the role of the Adjoint Model?",
      options: ["To integrate the gradient of the cost function backwards in time to obtain initial condition sensitivities", "To project satellite radiances onto radar beams", "To predict climate over 100 years", "To smooth horizontal topography"],
      correct: 0,
      marks: 4,
      difficulty: "Hard",
      explanation: "The adjoint model integrates sensitivities backwards in time to minimize cost function J with respect to initial state vector x0."
    }
  ],
  radar: [
    {
      q: "In dual-polarization weather radar, what physical property does Differential Reflectivity (ZDR) primarily measure?",
      options: ["The median oblateness/eccentricity of hydrometeors (horizontal vs vertical diameter ratio)", "Total precipitation volume only", "Wind shear speed in knots", "Echo top height above sea level"],
      correct: 0,
      marks: 2,
      difficulty: "Easy",
      explanation: "ZDR = 10 * log10(Zh / Zv), giving direct insight into hydrometeor shapes (large raindrops flatten, creating positive ZDR)."
    },
    {
      q: "What Doppler radar velocity signature indicates an intense downburst / microburst impacting the surface?",
      options: ["Strong low-level radial velocity divergence centered at the precipitation core", "Uniform cyclonic rotation at 10 km altitude", "Pure inbound velocities with zero outbound", "Broad spectrum width without velocity gradient"],
      correct: 0,
      marks: 3,
      difficulty: "Medium",
      explanation: "As the downdraft strikes the ground, it spreads outward horizontally, causing a divergent radial velocity signature near ground level."
    },
    {
      q: "Which radar product is critical for estimating instantaneous Surface Rain Intensity (SRI) with reduced ground clutter contamination?",
      options: ["Hybrid Scan Reflectivity (HSR) / CAPPI at lowest uncontaminated beam height", "Base Reflectivity at 19.5 degree tilt", "Storm Total Accumulation without clutter filter", "Raw spectrum width at maximum range"],
      correct: 0,
      marks: 3,
      difficulty: "Medium",
      explanation: "Hybrid Scan Reflectivity selects the lowest unblocked, clutter-free radar bin for accurate Quantitative Precipitation Estimation (QPE)."
    }
  ],
  cyclone: [
    {
      q: "In the Dvorak Tropical Cyclone analysis, what defines the 'Curved Band Pattern' logarithmic spiral angle?",
      options: ["The extent in fractions of 10-degree logarithmic spirals that the dense overcast cloud band wraps around the storm center", "The total diameter of the storm in nautical miles", "The sea surface temperature gradient alone", "The upper tropospheric divergence outflow rate"],
      correct: 0,
      marks: 2,
      difficulty: "Medium",
      explanation: "The curved band pattern measures the degree of band curvature (e.g. 0.5 to 1.5 spirals) to determine the Data T-number."
    },
    {
      q: "What Sea Surface Temperature (SST) and Ocean Thermal Energy (TCHP) threshold is generally considered supportive of rapid tropical cyclone intensification?",
      options: ["SST >= 28.0°C and Tropical Cyclone Heat Potential (TCHP) > 60-80 kJ/cm²", "SST >= 22.0°C and TCHP < 20 kJ/cm²", "SST >= 18.0°C only", "Surface salinity > 40 PSU"],
      correct: 0,
      marks: 2,
      difficulty: "Easy",
      explanation: "Deep warm oceanic mixed layers (TCHP > 60 kJ/cm²) prevent upwelling-induced cooling and fuel rapid cyclogenesis."
    },
    {
      q: "What is the primary operational cause of catastrophic coastal inundation during severe cyclone landfall?",
      options: ["Storm surge driven by astronomical high tide combined with extreme onshore wind stress and low barometric pressure", "Freshwater rainfall accumulation only", "Tsunami waves generated by seismic faults", "Thermal expansion of coastal lagoons"],
      correct: 0,
      marks: 3,
      difficulty: "Medium",
      explanation: "Storm surge is the abnormal rise of water generated by a storm's wind stress and atmospheric pressure drop, exacerbated at astronomical high tide."
    }
  ],
  satellite: [
    {
      q: "What key advantage does the INSAT-3D/3DR Thermal Infrared split-window technique (10.8 µm vs 12.0 µm) provide?",
      options: ["Correcting for atmospheric moisture absorption to accurately calculate Sea Surface Temperature (SST) and cloud-top properties", "Measuring radar reflectivity inside clouds", "Detecting underground magma reservoirs", "Directly recording surface soil moisture in forests"],
      correct: 0,
      marks: 3,
      difficulty: "Medium",
      explanation: "Differential water vapor absorption in the two adjacent thermal infrared windows allows accurate SST and low-level moisture retrieval."
    },
    {
      q: "Which product derived from geostationary meteorological satellites provides high-density tropospheric wind vectors?",
      options: ["Atmospheric Motion Vectors (AMVs) / Cloud Motion Vectors", "Outgoing Longwave Radiation (OLR) index", "Hydro-Estimator Rainfall Index", "Normalized Difference Vegetation Index (NDVI)"],
      correct: 0,
      marks: 2,
      difficulty: "Easy",
      explanation: "AMVs are tracked by cross-correlating cloud and moisture features across consecutive rapid-scan satellite images."
    }
  ]
};

export const generateQuestionsWithAI = async (req, res) => {
  try {
    const { topic = "Numerical Weather Prediction", difficulty = "Medium", count = 3, module = "Module 1", subjectName = "Atmospheric Sciences" } = req.body;

    const topicLower = topic.toLowerCase();
    let templatePool = domainKnowledge.nwp;

    if (topicLower.includes("radar") || topicLower.includes("dwr") || topicLower.includes("polariz")) {
      templatePool = domainKnowledge.radar;
    } else if (topicLower.includes("cyclone") || topicLower.includes("storm") || topicLower.includes("dvorak")) {
      templatePool = domainKnowledge.cyclone;
    } else if (topicLower.includes("satellite") || topicLower.includes("insat") || topicLower.includes("remote")) {
      templatePool = domainKnowledge.satellite;
    }

    const numToGenerate = Math.min(Math.max(Number(count) || 3, 1), 10);
    const generatedQuestions = [];

    for (let i = 0; i < numToGenerate; i++) {
      const template = templatePool[i % templatePool.length];
      const marks = difficulty === "Hard" ? 5 : (difficulty === "Medium" ? 3 : 2);

      // Custom synthesis
      const questionItem = {
        id: `ai_q_${uuidv4().substring(0, 8)}`,
        question: template.q,
        subjectName: subjectName || "Meteorological Specialization",
        module: module || `Module ${((i % 3) + 1)}`,
        marks: marks,
        type: "MCQ",
        difficulty: difficulty || template.difficulty,
        options: [...template.options],
        correctAnswer: template.correct,
        explanation: template.explanation,
        generatedByAI: true,
        aiModel: "IMD-MoES Domain AI Engine v2.5"
      };

      generatedQuestions.push(questionItem);
    }

    return res.json({
      success: true,
      message: `AI successfully generated ${generatedQuestions.length} meteorological assessment questions based on topic "${topic}" and difficulty "${difficulty}".`,
      topic,
      difficulty,
      generatedQuestions
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};
