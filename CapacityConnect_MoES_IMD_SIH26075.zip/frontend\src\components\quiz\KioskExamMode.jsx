import React, { useState, useEffect } from "react";
import { 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  Bookmark, 
  CheckCircle2, 
  AlertTriangle, 
  Award, 
  ShieldCheck, 
  Maximize2,
  X,
  FileCheck
} from "lucide-react";
import confetti from "canvas-confetti";
import { api } from "../../services/api";

export const KioskExamMode = ({ quiz, currentUser, onClose, onFinish }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({}); // { [questionId]: selectedOptionIndex }
  const [markedForReview, setMarkedForReview] = useState({}); // { [questionId]: boolean }
  const [visited, setVisited] = useState({ [quiz.questions[0]?.id]: true });
  const [timeLeftSeconds, setTimeLeftSeconds] = useState((quiz.durationMinutes || 30) * 60);
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState(null);

  const questions = quiz.questions || [];
  const currentQuestion = questions[currentIndex] || {};

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitQuiz(); // Auto submit on timer expiry
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format time HH:MM:SS
  const formatTime = (secs) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${String(h).padStart(2, '0')} : ${String(m).padStart(2, '0')} : ${String(s).padStart(2, '0')}`;
  };

  // Anti-cheat tab switch detection
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && !submissionResult) {
        setTabSwitchCount(prev => prev + 1);
        setShowWarningModal(true);
      }
    };

    window.addEventListener("visibilitychange", handleVisibilityChange);
    return () => window.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [submissionResult]);

  // Navigate question
  const goToQuestion = (idx) => {
    if (idx < 0 || idx >= questions.length) return;
    setCurrentIndex(idx);
    const targetQ = questions[idx];
    if (targetQ) {
      setVisited(prev => ({ ...prev, [targetQ.id]: true }));
    }
  };

  // Toggle answer
  const handleSelectOption = (optIdx) => {
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: optIdx }));
  };

  // Toggle review flag
  const toggleMarkForReview = () => {
    setMarkedForReview(prev => ({
      ...prev,
      [currentQuestion.id]: !prev[currentQuestion.id]
    }));
  };

  // Question status color helper
  const getQuestionStatus = (q, idx) => {
    const isAns = answers[q.id] !== undefined;
    const isRev = !!markedForReview[q.id];
    const isVis = !!visited[q.id];

    if (isRev) return "review"; // Blue
    if (isAns) return "answered"; // Green
    if (isVis) return "not-answered"; // Orange/Peach
    return "not-visited"; // Gray
  };

  // Summary counts
  const answeredCount = questions.filter(q => answers[q.id] !== undefined && !markedForReview[q.id]).length;
  const markedReviewCount = questions.filter(q => markedForReview[q.id]).length;
  const notAnsweredCount = questions.filter(q => visited[q.id] && answers[q.id] === undefined && !markedForReview[q.id]).length;
  const notVisitedCount = questions.filter(q => !visited[q.id]).length;

  // Submit assessment
  const handleSubmitQuiz = async () => {
    setSubmitting(true);
    try {
      const timeTaken = (quiz.durationMinutes * 60) - timeLeftSeconds;
      const payload = {
        quizId: quiz.id,
        traineeId: currentUser?.id || "u_trainee_1",
        traineeName: currentUser?.name || "Rahul Sharma",
        traineeEmail: currentUser?.email || "rahul.sharma@imd.gov.in",
        answers,
        timeTakenSeconds: timeTaken,
        tabSwitchCount
      };

      const res = await api.submitQuiz(payload);
      if (res.success) {
        setSubmissionResult(res.submission);
        if (res.submission.passed) {
          confetti({
            particleCount: 120,
            spread: 70,
            origin: { y: 0.6 }
          });
        }
      }
    } catch (err) {
      alert("Submission error: " + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // If already submitted -> Render Instant Result Card with Certificate generator
  if (submissionResult) {
    return (
      <div className="fixed inset-0 bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-4 z-50 overflow-y-auto">
        <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl border border-slate-200 text-center animate-in zoom-in-95 duration-200 my-8">
          <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4 bg-emerald-100 text-emerald-600 shadow-inner">
            <Award className="w-8 h-8" />
          </div>

          <h2 className="text-2xl font-bold text-slate-900 mb-1">
            Assessment Completed!
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            {quiz.title} • Ministry of Earth Sciences (MoES)
          </p>

          {/* Score Badge */}
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 mb-6 grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Score Obtained</p>
              <p className="text-2xl font-black text-[#0a2558] mt-1">
                {submissionResult.score} / {submissionResult.totalMarks}
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Percentage</p>
              <p className="text-2xl font-black text-emerald-600 mt-1">
                {submissionResult.percentage}%
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Status</p>
              <span className="inline-block mt-1 px-3 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                {submissionResult.passed ? "PASSED" : "NEEDS RETAKE"}
              </span>
            </div>
          </div>

          {/* Certificate Generation notification */}
          {submissionResult.certificateGenerated && (
            <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-medium mb-6 flex items-center gap-3 text-left">
              <ShieldCheck className="w-6 h-6 text-blue-700 shrink-0" />
              <div>
                <p className="font-bold">Official MoES Competency Credential Generated!</p>
                <p className="text-[11px] text-blue-700">Certificate ID: {submissionResult.certificateId}</p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => {
                if (onFinish) onFinish();
                onClose();
              }}
              className="px-6 py-2.5 bg-[#0a2558] hover:bg-[#071c42] text-white rounded-xl text-xs font-bold shadow-lg transition-transform hover:scale-105"
            >
              Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#f8fafc] z-50 flex flex-col select-none overflow-hidden font-sans">
      {/* Kiosk Mode Header strictly matching Screenshot 2 */}
      <header className="h-16 bg-[#0a2558] text-white px-8 flex items-center justify-between shadow-md shrink-0">
        <div>
          <h1 className="text-lg font-bold tracking-tight">
            {quiz.title || "Capacity Assessment"}
          </h1>
          <p className="text-xs text-blue-200/80 font-normal">
            👤 {currentUser?.email || "user@imd.gov.in"} &nbsp;•&nbsp; 🏛️ {currentUser?.department || "Institute 1 (IMD)"}
          </p>
        </div>

        {/* Digital Countdown Clock matching Screenshot 2: 01 : 24 : 13 */}
        <div className="flex items-center gap-3 bg-black/25 px-4 py-2 rounded-xl border border-white/10 shadow-inner">
          <Clock className="w-4 h-4 text-blue-300 animate-pulse" />
          <span className="font-mono text-base font-bold tracking-widest text-white">
            {formatTime(timeLeftSeconds)}
          </span>
        </div>
      </header>

      {/* Main Kiosk Content Area (Two Columns matching Screenshot 2) */}
      <div className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden max-w-7xl mx-auto w-full">
        {/* Left Column: Question Presentation Area */}
        <div className="lg:col-span-8 flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm p-6 overflow-y-auto">
          {/* Top badges matching Screenshot 2: Q18, 2 marks, MCQ */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-[#0a2558] text-white rounded-lg text-xs font-bold tracking-wide">
                Q{currentIndex + 1}
              </span>
              <span className="text-xs font-semibold text-slate-500">
                {currentQuestion.marks || 2} marks
              </span>
            </div>

            <span className="px-3 py-1 bg-[#0a2558] text-white rounded-full text-[11px] font-semibold tracking-wider">
              {currentQuestion.type || "MCQ"}
            </span>
          </div>

          {/* Question Prompt */}
          <div className="py-6">
            <h2 className="text-base md:text-lg font-medium text-slate-900 leading-relaxed">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Selectable Options Stack matching Screenshot 2 (A., B., C., D.) */}
          <div className="space-y-3.5 mt-auto pb-4">
            {currentQuestion.options && currentQuestion.options.map((opt, optIdx) => {
              const isSelected = answers[currentQuestion.id] === optIdx;
              const letter = String.fromCharCode(65 + optIdx);

              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-150 flex items-start gap-3.5 text-xs md:text-sm ${
                    isSelected
                      ? "bg-blue-50/80 border-[#0a2558] text-[#0a2558] font-semibold ring-2 ring-[#0a2558]/20 shadow-sm"
                      : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70 text-slate-700"
                  }`}
                >
                  <span className={`w-6 h-6 rounded-full border flex items-center justify-center font-bold text-xs shrink-0 ${
                    isSelected ? "bg-[#0a2558] text-white border-[#0a2558]" : "bg-slate-100 text-slate-600 border-slate-300"
                  }`}>
                    {letter}
                  </span>
                  <span className="leading-relaxed pt-0.5">{opt}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Question Navigator Grid matching Screenshot 2 */}
        <div className="lg:col-span-4 flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm p-5 overflow-y-auto">
          <h3 className="font-bold text-slate-800 text-sm mb-3">Question Navigator</h3>

          {/* Section 1 Grid */}
          <div className="mb-4">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Atmospheric Dynamics & Radar Physics
            </p>
            <div className="grid grid-cols-5 gap-2">
              {questions.slice(0, 25).map((q, idx) => {
                const status = getQuestionStatus(q, idx);
                const isCurrent = currentIndex === idx;

                let bgClasses = "bg-slate-100 text-slate-600 border-slate-200"; // not visited
                if (status === "answered") bgClasses = "bg-[#d1fae5] text-[#065f46] border-[#a7f3d0] font-bold"; // Light green
                if (status === "not-answered") bgClasses = "bg-[#fef3c7] text-[#92400e] border-[#fde68a]"; // Peach/yellow
                if (status === "review") bgClasses = "bg-[#dbeafe] text-[#1e40af] border-[#bfdbfe] font-bold"; // Soft blue

                if (isCurrent) {
                  bgClasses = "bg-[#0a2558] text-white border-[#0a2558] font-black ring-2 ring-blue-300 shadow-md";
                }

                return (
                  <button
                    key={q.id || idx}
                    onClick={() => goToQuestion(idx)}
                    className={`h-9 rounded-lg border text-xs flex items-center justify-center transition-all ${bgClasses}`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2 Grid if > 25 questions */}
          {questions.length > 25 && (
            <div className="mb-4">
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Operational Nowcasting & Cyclone Tech
              </p>
              <div className="grid grid-cols-5 gap-2">
                {questions.slice(25).map((q, idx) => {
                  const actualIdx = idx + 25;
                  const status = getQuestionStatus(q, actualIdx);
                  const isCurrent = currentIndex === actualIdx;

                  let bgClasses = "bg-slate-100 text-slate-600 border-slate-200";
                  if (status === "answered") bgClasses = "bg-[#d1fae5] text-[#065f46] border-[#a7f3d0] font-bold";
                  if (status === "not-answered") bgClasses = "bg-[#fef3c7] text-[#92400e] border-[#fde68a]";
                  if (status === "review") bgClasses = "bg-[#dbeafe] text-[#1e40af] border-[#bfdbfe] font-bold";

                  if (isCurrent) {
                    bgClasses = "bg-[#0a2558] text-white border-[#0a2558] font-black ring-2 ring-blue-300";
                  }

                  return (
                    <button
                      key={q.id || actualIdx}
                      onClick={() => goToQuestion(actualIdx)}
                      className={`h-9 rounded-lg border text-xs flex items-center justify-center transition-all ${bgClasses}`}
                    >
                      {actualIdx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Color Status Legend Summary Box strictly matching Screenshot 2 */}
          <div className="mt-auto pt-4 border-t border-slate-100">
            <h4 className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2.5">Summary</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-[#d1fae5]/80 text-[#065f46] border border-[#a7f3d0] font-medium flex items-center justify-between">
                <span>{answeredCount} Answered</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#fef3c7]/90 text-[#92400e] border border-[#fde68a] font-medium flex items-center justify-between">
                <span>{notAnsweredCount} Not Answered</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#dbeafe]/80 text-[#1e40af] border border-[#bfdbfe] font-medium flex items-center justify-between">
                <span>{markedReviewCount} Marked For Review</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100 text-slate-600 border border-slate-200 font-medium flex items-center justify-between">
                <span>{notVisitedCount} Not Visited</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Bottom Action Bar strictly matching Screenshot 2 */}
      <footer className="h-16 bg-white border-t border-slate-200 px-8 flex items-center justify-between shadow-lg shrink-0">
        {/* Left: Previous Question */}
        <button
          disabled={currentIndex === 0}
          onClick={() => goToQuestion(currentIndex - 1)}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold border transition-colors ${
            currentIndex === 0
              ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
              : "bg-[#0a2558] text-white hover:bg-[#071c42] border-[#0a2558]"
          }`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Prev</span>
        </button>

        {/* Center: Mark For Review & Next */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleMarkForReview}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold border transition-colors ${
              markedForReview[currentQuestion.id]
                ? "bg-blue-600 text-white border-blue-600"
                : "bg-white text-[#0a2558] border-[#0a2558] hover:bg-blue-50"
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>{markedForReview[currentQuestion.id] ? "Unmark Review" : "Mark For Review"}</span>
          </button>

          <button
            disabled={currentIndex === questions.length - 1}
            onClick={() => goToQuestion(currentIndex + 1)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold border transition-colors ${
              currentIndex === questions.length - 1
                ? "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                : "bg-[#0a2558] text-white hover:bg-[#071c42] border-[#0a2558]"
            }`}
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Submit Quiz Button matching Screenshot 2 */}
        <button
          onClick={() => {
            if (window.confirm("Are you sure you want to submit your assessment?")) {
              handleSubmitQuiz();
            }
          }}
          disabled={submitting}
          className="flex items-center gap-2 px-6 py-2.5 bg-[#0a2558] hover:bg-[#071c42] text-white rounded-lg text-xs font-bold shadow-md transition-transform hover:scale-105"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-300" />
          <span>{submitting ? "Submitting..." : "✓ Submit Quiz"}</span>
        </button>
      </footer>

      {/* Anti-Cheat Tab Switch Warning Modal */}
      {showWarningModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border-2 border-amber-400 text-center">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 mx-auto flex items-center justify-center mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Kiosk Proctoring Alert
            </h3>
            <p className="text-xs text-slate-600 mb-4">
              Tab or window switching detected. This event has been recorded in your examination log (Count: {tabSwitchCount}). Please stay focused on the assessment window.
            </p>
            <button
              onClick={() => setShowWarningModal(false)}
              className="w-full py-2 bg-[#0a2558] text-white rounded-xl text-xs font-bold"
            >
              I Understand & Resume Assessment
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
