import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  HelpCircle, 
  ClipboardList, 
  BarChart3, 
  Sparkles, 
  Plus, 
  Users, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  TrendingUp,
  FileText
} from "lucide-react";
import { api } from "../../services/api";

export const TrainerDashboardView = ({ 
  currentUser, 
  onOpenQuestionBank, 
  onOpenAiGenerator, 
  onOpenScheduleQuiz, 
  onOpenAnalytics, 
  onOpenCourse 
}) => {
  const [courses, setCourses] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [questionsCount, setQuestionsCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTrainerData = async () => {
      setLoading(true);
      try {
        const [cRes, qRes, qbRes] = await Promise.all([
          api.getCourses(),
          api.getQuizzes(),
          api.getQuestions()
        ]);

        if (cRes.success) setCourses(cRes.courses);
        if (qRes.success) setQuizzes(qRes.quizzes);
        if (qbRes.success) setQuestionsCount(qbRes.count || qbRes.questions?.length || 0);
      } catch (err) {
        console.error("Trainer dashboard load error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadTrainerData();
  }, [currentUser]);

  return (
    <div className="p-6 space-y-6">
      {/* Trainer Banner */}
      <div className="bg-gradient-to-r from-[#0a2558] via-blue-900 to-indigo-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250"}
            alt={currentUser?.name}
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-white/30 shadow-lg"
          />
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold tracking-tight">
                {currentUser?.name || "Dr. Amit Sengupta"}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/20 uppercase tracking-wider">
                Senior Lead Trainer
              </span>
            </div>
            <p className="text-xs text-blue-200">
              {currentUser?.designation} • {currentUser?.department}
            </p>
          </div>
        </div>

        {/* Action Shortcuts */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenAiGenerator}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition-all transform hover:scale-105"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span>AI Question Generator</span>
          </button>

          <button
            onClick={onOpenScheduleQuiz}
            className="flex items-center gap-1.5 px-4 py-2 bg-white text-[#0a2558] hover:bg-blue-50 font-bold rounded-xl text-xs shadow-md transition-all transform hover:scale-105"
          >
            <Plus className="w-4 h-4 text-[#0a2558]" />
            <span>Schedule Assessment</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase">Assigned Courses</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-[#0a2558]">{courses.length}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase">Active Quizzes</span>
            <ClipboardList className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-600">{quizzes.length}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase">Question Bank Items</span>
            <HelpCircle className="w-4 h-4 text-purple-600" />
          </div>
          <p className="text-2xl font-black text-purple-900">{questionsCount}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase">Avg Class Pass Rate</span>
            <TrendingUp className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-2xl font-black text-indigo-900">95.4%</p>
        </div>
      </div>

      {/* Scheduled Assessments & 1-Click Analytics Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Assigned Assessments & 1-Click Evaluation Engine
            </h2>
            <p className="text-xs text-slate-500">
              Manage scheduled start windows, deadlines, and inspect real-time trainee performance charts
            </p>
          </div>
          <button
            onClick={onOpenScheduleQuiz}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#0a2558] text-white rounded-lg text-xs font-bold shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Quiz</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Assessment Title</th>
                <th className="py-3 px-4">Associated Course</th>
                <th className="py-3 px-4 text-center">Duration</th>
                <th className="py-3 px-4 text-center">Pass Marks</th>
                <th className="py-3 px-4 text-center">Questions</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {quizzes.map(q => (
                <tr key={q.id} className="hover:bg-slate-50">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{q.title}</td>
                  <td className="py-3.5 px-4 text-slate-600">{q.courseName || "IMD Course"}</td>
                  <td className="py-3.5 px-4 text-center text-slate-600">{q.durationMinutes} mins</td>
                  <td className="py-3.5 px-4 text-center font-bold text-[#0a2558]">{q.passMarks}/{q.totalMarks}</td>
                  <td className="py-3.5 px-4 text-center">{q.questions?.length || 4}</td>
                  <td className="py-3.5 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      PUBLISHED
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => onOpenAnalytics(q.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#0a2558] font-bold rounded-lg text-xs transition-colors ml-auto shadow-sm"
                    >
                      <BarChart3 className="w-3.5 h-3.5" />
                      <span>1-Click Analytics</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Courses Managed */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
          Trainer Content Library & Curriculum
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {courses.map(course => (
            <div
              key={course.id}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-start justify-between gap-4"
            >
              <div>
                <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  {course.code}
                </span>
                <h3 className="font-bold text-slate-900 text-xs mt-1.5">{course.title}</h3>
                <p className="text-[11px] text-slate-500 mt-1">
                  Enrolled Trainees: <b>{course.enrolledTraineeIds?.length || 2}</b> • Subjects: {course.subjects?.length || 2}
                </p>
              </div>
              <button
                onClick={() => onOpenCourse(course)}
                className="px-3.5 py-1.5 bg-slate-100 hover:bg-[#0a2558] hover:text-white text-slate-700 font-bold rounded-lg text-xs transition-colors shrink-0"
              >
                Manage Material
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
