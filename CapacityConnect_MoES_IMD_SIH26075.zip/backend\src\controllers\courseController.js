import { db } from "../store/dbStore.js";

export const getCourses = (req, res) => {
  try {
    const courses = db.getCourses();
    return res.json({ success: true, count: courses.length, courses });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const getCourseById = (req, res) => {
  try {
    const { id } = req.params;
    const course = db.getCourseById(id);
    if (!course) {
      return res.status(404).json({ success: false, message: "Course not found" });
    }
    return res.json({ success: true, course });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const enrollCourse = (req, res) => {
  try {
    const { id } = req.params;
    const { traineeId } = req.body;
    if (!traineeId) {
      return res.status(400).json({ success: false, message: "Trainee ID is required" });
    }
    const course = db.enrollTrainee(id, traineeId);
    if (!course) {
      return res.status(404).json({ success: false, message: "Course not found" });
    }
    return res.json({ success: true, message: "Successfully enrolled in course!", course });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const createCourse = (req, res) => {
  try {
    const course = db.createCourse(req.body);
    return res.status(201).json({ success: true, message: "Course created successfully", course });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const uploadLearningMaterial = (req, res) => {
  try {
    const { courseId, subjectId, moduleId } = req.params;
    const materialData = req.body;
    const material = db.addMaterialToModule(courseId, subjectId, moduleId, materialData);
    if (!material) {
      return res.status(404).json({ success: false, message: "Course, Subject or Module not found" });
    }
    return res.status(201).json({
      success: true,
      message: "Material added to module successfully with download permissions set.",
      material
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const getFeedbacks = (req, res) => {
  try {
    const { courseId } = req.query;
    const feedbacks = db.getFeedbacks(courseId);
    return res.json({ success: true, feedbacks });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const submitFeedback = (req, res) => {
  try {
    const fb = db.addFeedback(req.body);
    return res.status(201).json({ success: true, message: "Feedback submitted successfully!", feedback: fb });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};
