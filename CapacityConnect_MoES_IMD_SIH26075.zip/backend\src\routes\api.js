import express from "express";
import * as authController from "../controllers/authController.js";
import * as courseController from "../controllers/courseController.js";
import * as quizController from "../controllers/quizController.js";
import * as competencyController from "../controllers/competencyController.js";
import * as adminController from "../controllers/adminController.js";
import * as aiController from "../controllers/aiController.js";

const router = express.Router();

// --- Auth & Profile ---
router.post("/auth/login", authController.login);
router.post("/auth/register", authController.register);
router.get("/users/profile/:id", authController.getProfile);
router.put("/users/profile/:id", authController.updateProfile);
router.post("/users/profile/:id/submit-approval", authController.submitProfileForApproval);

// --- Courses & Learning Materials ---
router.get("/courses", courseController.getCourses);
router.get("/courses/:id", courseController.getCourseById);
router.post("/courses", courseController.createCourse);
router.post("/courses/:id/enroll", courseController.enrollCourse);
router.post("/courses/:courseId/subjects/:subjectId/modules/:moduleId/materials", courseController.uploadLearningMaterial);
router.get("/feedback", courseController.getFeedbacks);
router.post("/feedback", courseController.submitFeedback);

// --- Question Bank & Quizzes (Matching UI references) ---
router.get("/questions", quizController.getQuestionBank);
router.post("/questions", quizController.createQuestion);
router.post("/questions/:id/duplicate", quizController.duplicateQuestion);
router.delete("/questions/:id", quizController.deleteQuestion);

// --- AI Question Generator ---
router.post("/ai/generate-questions", aiController.generateQuestionsWithAI);

// --- Quizzes, Kiosk Mode, Submissions & Analytics ---
router.get("/quizzes", quizController.getQuizzes);
router.get("/quizzes/:id", quizController.getQuizById);
router.post("/quizzes", quizController.createQuiz);
router.post("/quizzes/submit", quizController.submitQuiz);
router.get("/quizzes/:id/analytics", quizController.getQuizAnalytics);
router.get("/analytics/trainee/:traineeId", quizController.getTraineeAnalytics);

// --- Competency Mapping Engine ---
router.get("/competencies", competencyController.getCompetencyMatrix);
router.post("/competencies/suggest-trainers", competencyController.suggestTrainersForSubject);
router.post("/competencies/:competencyId/assign", competencyController.assignTrainerToCompetency);

// --- Admin Endpoints ---
router.get("/admin/stats", adminController.getAdminStats);
router.get("/admin/users/pending", adminController.getPendingUsers);
router.get("/admin/users", adminController.getAllUsers);
router.post("/admin/users/:id/verify", adminController.verifyUser);
router.get("/announcements", adminController.getAnnouncements);
router.post("/announcements", adminController.publishAnnouncement);

export default router;
