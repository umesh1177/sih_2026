import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  ClipboardList, 
  Award, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Sparkles, 
  PlayCircle,
  BarChart3,
  FileText,
  User,
  ShieldCheck,
  ChevronRight
} from "lucide-react";
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer 
} from "recharts";
import { api } from "../../services/api";

export const TraineeDashboardView = ({ 
  currentUser, 
  onStartExam, 
  onOpenCourse, 
  onOpenProfile, 
  onOpenCertificate 
}) => {
  const [quizzes, setQuizzes] = useState([]);
  const [courses, setCourses] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [qRes, cRes, aRes] = await Promise.all([
          api.getQuizzes(),
          api.getCourses(),
          api.getTraineeAnalytics(currentUser?.id || "u_trainee_1")
        ]);

        if (qRes.success) setQuizzes(qRes.quizzes);
        if (cRes.success) setCourses(cRes.courses);
        if (aRes.success) setAnalytics(aRes);
      } catch (err) {
        console.error("Dashboard load failed:", err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [currentUser]);

  const enrolledCourses = courses.filter(c => (c.enrolledTraineeIds || []).includes(currentUser?.id));
  const otherCourses = courses.filter(c => !(c.enrolledTraineeIds || []).includes(currentUser?.id));

  // Determine if quiz is currently active or scheduled for later
  const isQuizAvailable = (quiz) => {
    const now = new Date();
    const start = new Date(quiz.scheduledStartTime);
    const end = new Date(quiz.deadlineTime);
    return now >= start && now <= end;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Officer Welcome & Verification Status Banner */}
      <div className="bg-gradient-to-r from-[#0a2558] via-blue-900 to-indigo-950 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250"}
            alt={currentUser?.name}
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-white/30 shadow-lg"
          />
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold tracking-tight">
                Welcome, {currentUser?.name || "Trainee Officer"}
              </h1>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                currentUser?.status === "approved" ? "bg-emerald-500 text-white" : "bg-amber-400 text-slate-900"
              }`}>
                {currentUser?.status === "approved" ? "Verified Officer" : "Pending Verification"}
              </span>
            </div>
            <p className="text-xs text-blue-200">
              {currentUser?.designation} • {currentUser?.department}
            </p>
          </div>
        </div>

        <button
          onClick={onOpenProfile}
          className="flex items-center gap-2 px-4 py-2 bg-white text-[#0a2558] hover:bg-blue-50 font-bold rounded-xl text-xs shadow-md transition-all transform hover:scale-105"
        >
          <User className="w-4 h-4" />
          <span>Manage Professional Profile</span>
        </button>
      </div>

      {/* Scheduled Assessments Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-[#0a2558]" />
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
              Scheduled Capacity Assessments (Kiosk Mode)
            </h2>
          </div>
          <span className="text-xs text-slate-400">Timed Proctoring Enabled</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quizzes.map((quiz) => {
            const available = isQuizAvailable(quiz);
            const submission = analytics?.submissions?.find(s => s.quizId === quiz.id);

            return (
              <div
                key={quiz.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-800">
                      {quiz.courseName || "Meteorology Assessment"}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {quiz.durationMinutes} Mins
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm mb-1 leading-snug">{quiz.title}</h3>
                  <p className="text-xs text-slate-500 mb-4">
                    Trainer: <b>{quiz.trainerName}</b> • Pass Marks: {quiz.passMarks}/{quiz.totalMarks}
                  </p>
                </div>

                {submission ? (
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Score: {submission.score}/{submission.totalMarks} ({submission.percentage}%)
                    </span>
                    {submission.certificateGenerated && (
                      <button
                        onClick={() => onOpenCertificate(submission, quiz.title, currentUser?.name)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold rounded-lg text-xs"
                      >
                        <Award className="w-3.5 h-3.5 text-amber-600" />
                        <span>View Certificate</span>
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-slate-500">
                      Card active: {new Date(quiz.scheduledStartTime).toLocaleDateString()}
                    </span>
                    <button
                      onClick={() => onStartExam(quiz)}
                      className="flex items-center gap-1.5 px-4 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white rounded-xl font-bold shadow-md transition-transform hover:scale-105"
                    >
                      <PlayCircle className="w-4 h-4 text-emerald-300" />
                      <span>Start Kiosk Exam</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid: Enrolled Courses & Competency Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Enrolled Courses */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#0a2558]" />
              <span>My Enrolled Courses ({enrolledCourses.length})</span>
            </h2>
          </div>

          <div className="space-y-3">
            {enrolledCourses.map(course => (
              <div
                key={course.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3.5">
                  <img
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                  />
                  <div>
                    <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                      {course.code}
                    </span>
                    <h3 className="font-bold text-slate-900 text-xs mt-1 leading-snug">{course.title}</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {course.subjects?.length || 2} Subjects • {course.duration}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onOpenCourse(course)}
                  className="px-4 py-2 bg-slate-100 hover:bg-[#0a2558] hover:text-white text-slate-800 rounded-xl text-xs font-bold transition-colors shrink-0"
                >
                  Enter Course
                </button>
              </div>
            ))}
          </div>

          {/* Other Available Catalog Courses */}
          {otherCourses.length > 0 && (
            <div className="pt-4 space-y-3">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Explore More IMD Capacity Programs
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {otherCourses.map(c => (
                  <div
                    key={c.id}
                    onClick={() => onOpenCourse(c)}
                    className="p-3.5 bg-white rounded-xl border border-slate-200 hover:border-slate-300 shadow-sm cursor-pointer transition-colors"
                  >
                    <p className="text-[10px] font-bold text-slate-400">{c.code}</p>
                    <h4 className="font-bold text-slate-800 text-xs mt-0.5 line-clamp-1">{c.title}</h4>
                    <p className="text-[11px] text-blue-700 font-semibold mt-2">View Curriculum & Syllabus →</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Personal Skill Radar Chart */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-[#0a2558]" />
                <span>Officer Competency Radar</span>
              </h3>
              <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                Tier-1 Qualified
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Evaluated based on proctored MCQ assessments and module completions
            </p>
          </div>

          <div className="h-64 w-full my-2">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="75%" data={analytics?.competencyRadar || []}>
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 9, fill: '#475569' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 8 }} />
                <Radar name="Officer Competency" dataKey="score" stroke="#0a2558" fill="#0a2558" fillOpacity={0.4} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 text-[11px] text-blue-900 flex items-center justify-between">
            <span>Overall Competency Index</span>
            <b className="text-sm font-black text-[#0a2558]">88.4 / 100</b>
          </div>
        </div>
      </div>
    </div>
  );
};
