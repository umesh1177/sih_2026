// Initial Mock Seed Data for CAPACITY CONNECT - MoES / IMD Portal

export const initialData = {
  users: [
    {
      id: "u_admin_1",
      name: "Dr. Mrutyunjay Mohapatra",
      email: "admin@imd.gov.in",
      role: "admin",
      department: "Directorate General of Meteorology, New Delhi",
      designation: "Director General & Chief Admin",
      status: "approved",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-10T09:00:00.000Z"
    },
    {
      id: "u_trainer_1",
      name: "Dr. Amit Sengupta",
      email: "amit.sengupta@imd.gov.in",
      role: "trainer",
      department: "Numerical Weather Prediction Division, New Delhi",
      designation: "Scientist 'F' & Senior Meteorologist",
      specialization: ["Numerical Weather Prediction", "WRF / GFS Modeling", "Ensemble Prediction"],
      experienceYears: 18,
      qualifications: "Ph.D. in Atmospheric Sciences (IIT Delhi), M.Sc. Meteorology (Pune University)",
      status: "approved",
      bio: "Lead trainer for global and regional NWP models with 18+ years of operational weather forecasting experience at MoES.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-12T10:30:00.000Z"
    },
    {
      id: "u_trainer_2",
      name: "Dr. Sunita Kulkarni",
      email: "sunita.k@imd.gov.in",
      role: "trainer",
      department: "Radar & Satellite Meteorology Division, Pune",
      designation: "Scientist 'E' & Radar Specialist",
      specialization: ["Doppler Weather Radar", "INSAT-3DR Products", "Nowcasting"],
      experienceYears: 14,
      qualifications: "Ph.D. in Radar Remote Sensing (ISRO/IISC), B.Tech Electronics",
      status: "approved",
      bio: "Expert in dual-polarization S/X band Doppler radars and convective storm nowcasting algorithms.",
      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-14T11:00:00.000Z"
    },
    {
      id: "u_trainer_3",
      name: "Dr. Rajiv Roy",
      email: "rajiv.roy@imd.gov.in",
      role: "trainer",
      department: "Cyclone Warning Division, Regional Meteorological Centre Kolkata",
      designation: "Scientist 'E' & Marine Forecaster",
      specialization: ["Tropical Cyclogenesis", "Storm Surge Modeling", "Ocean Meteorology"],
      experienceYears: 12,
      qualifications: "M.Tech Ocean Engineering (IIT Kharagpur), M.Sc. Physics",
      status: "approved",
      bio: "Specialized in Bay of Bengal tropical cyclone track prediction and coastal vulnerability assessment.",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-15T14:20:00.000Z"
    },
    {
      id: "u_trainer_pending",
      name: "Dr. Meenakshi Sundaram",
      email: "meenakshi.s@imd.gov.in",
      role: "trainer",
      department: "Agrometeorology Division, Pune",
      designation: "Scientist 'D'",
      specialization: ["Agrometeorology", "Drought Monitoring", "Crop Weather Modeling"],
      experienceYears: 9,
      qualifications: "Ph.D. in Agricultural Meteorology (IARI New Delhi)",
      status: "pending",
      bio: "Awaiting approval for conducting training modules on Block-Level Agromet Advisory Services.",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-02-01T08:15:00.000Z"
    },
    {
      id: "u_trainee_1",
      name: "Rahul Sharma",
      email: "rahul.sharma@imd.gov.in",
      role: "trainee",
      department: "Meteorological Centre, Jaipur",
      designation: "Scientist 'B' (Trainee)",
      status: "approved",
      interests: ["NWP Models", "Satellite Imagery", "Severe Weather Warnings"],
      skills: ["Python for Meteorology", "Synoptic Analysis", "QGIS", "Data Assimilation"],
      qualifications: "M.Sc. Physics (University of Rajasthan), Advanced Post Graduate Diploma in Meteorology (IMD Pune)",
      experience: "2 years as Trainee Scientific Assistant at IMD Jaipur Field Station.",
      certificates: [
        { title: "Basic Meteorological Forecaster (BMF)", issuer: "IMD Training Centre Pune", year: "2024" },
        { title: "Python in Atmospheric Sciences", issuer: "MoES Digital Academy", year: "2024" }
      ],
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-20T10:00:00.000Z"
    },
    {
      id: "u_trainee_2",
      name: "Priya Varma",
      email: "priya.varma@imd.gov.in",
      role: "trainee",
      department: "Cyclone Warning Centre, Visakhapatnam",
      designation: "Assistant Meteorologist Grade-I",
      status: "approved",
      interests: ["Cyclone Tracking", "Radar Meteorology", "Disaster Management"],
      skills: ["Radar Data Interpretation", "Dvorak Technique", "Weather Chart Analysis"],
      qualifications: "B.Tech Atmospheric Technology (CUSAT Cochin)",
      experience: "3 years in Coastal Weather Observation & Radar Monitoring.",
      certificates: [
        { title: "Radar Meteorology Fundamentals", issuer: "MoES IMD", year: "2024" }
      ],
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-01-22T12:00:00.000Z"
    },
    {
      id: "u_trainee_pending",
      name: "Aniket Deshmukh",
      email: "aniket.d@imd.gov.in",
      role: "trainee",
      department: "Regional Meteorological Centre, Mumbai",
      designation: "Scientific Assistant Grade-II",
      status: "pending",
      interests: ["Urban Flood Forecasting", "Nowcasting", "Doppler Radar"],
      skills: ["Surface Observations", "AWS Data Analysis"],
      qualifications: "B.Sc. Physics (Mumbai University)",
      experience: "1 year field station maintenance & weather bulletin compilation.",
      certificates: [],
      avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=250",
      createdAt: "2025-02-04T15:30:00.000Z"
    }
  ],

  courses: [
    {
      id: "crs_nwp_101",
      code: "MOES-IMD-NWP-2025",
      title: "Advanced Numerical Weather Prediction (NWP) & Data Assimilation",
      category: "Atmospheric Modeling",
      level: "Intermediate to Advanced",
      duration: "6 Weeks (48 Hours)",
      creditHours: 4,
      department: "Numerical Weather Prediction Division",
      leadTrainerId: "u_trainer_1",
      leadTrainerName: "Dr. Amit Sengupta",
      thumbnail: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&q=80&w=800",
      description: "Master modern atmospheric dynamics, grid generation, parameterizations, WRF/GFS model physics, ensemble prediction systems (EPS), and 3D/4D-Var data assimilation for operational weather forecasting in India.",
      prerequisites: ["Fluid Dynamics Fundamentals", "Basic Meteorology", "Linux & Shell Scripting"],
      enrolledTraineeIds: ["u_trainee_1"],
      competenciesGained: ["NWP Grid Physics", "WRF Execution", "Data Assimilation", "EPS Probability Mapping"],
      subjects: [
        {
          id: "sub_nwp_01",
          name: "Subject 1: Governing Equations & Atmospheric Dynamics",
          modules: [
            {
              id: "mod_01",
              title: "Module 1: Navier-Stokes & Primitive Equation Systems",
              duration: "4 Hours",
              materials: [
                {
                  id: "mat_01",
                  title: "Lecture 1: Primitive Equations in Sigma & Pressure Coordinates",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "45 mins",
                  allowDownload: false
                },
                {
                  id: "mat_02",
                  title: "Presentation: Atmospheric Governing Equations Deck",
                  type: "presentation",
                  url: "https://example.com/slides/dynamics_part1.pdf",
                  pages: 34,
                  allowDownload: true
                },
                {
                  id: "mat_03",
                  title: "Study Guide: Boundary Layer Parameterization Notes",
                  type: "pdf",
                  url: "https://example.com/notes/nwp_pbl_notes.pdf",
                  size: "2.4 MB",
                  allowDownload: true
                }
              ]
            },
            {
              id: "mod_02",
              title: "Module 2: Discretization & Spatial-Temporal Grid Staggering",
              duration: "6 Hours",
              materials: [
                {
                  id: "mat_04",
                  title: "Lecture 2: Arakawa Grids (A-E) & Courant-Friedrichs-Lewy (CFL) Condition",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "52 mins",
                  allowDownload: false
                },
                {
                  id: "mat_05",
                  title: "Lab Manual: Configuring WRF Preprocessing System (WPS)",
                  type: "pdf",
                  url: "https://example.com/notes/wps_config_manual.pdf",
                  size: "5.1 MB",
                  allowDownload: true
                }
              ]
            }
          ]
        },
        {
          id: "sub_nwp_02",
          name: "Subject 2: Data Assimilation & Satellite Radiance Ingestion",
          modules: [
            {
              id: "mod_03",
              title: "Module 3: 3D-Var / 4D-Var & Kalman Filtering in NWP",
              duration: "5 Hours",
              materials: [
                {
                  id: "mat_06",
                  title: "Lecture 3: Assimilating INSAT-3DR and Doppler Radar Reflectivity",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "48 mins",
                  allowDownload: false
                },
                {
                  id: "mat_07",
                  title: "Slide Deck: Background Error Covariance (B-Matrix) Estimation",
                  type: "presentation",
                  url: "https://example.com/slides/da_covariances.pdf",
                  pages: 42,
                  allowDownload: true
                }
              ]
            }
          ]
        }
      ]
    },
    {
      id: "crs_dwr_102",
      code: "MOES-IMD-DWR-2025",
      title: "Doppler Weather Radar (DWR) Operational Data Interpretation & Nowcasting",
      category: "Radar & Remote Sensing",
      level: "Intermediate",
      duration: "4 Weeks (32 Hours)",
      creditHours: 3,
      department: "Radar & Satellite Meteorology Division",
      leadTrainerId: "u_trainer_2",
      leadTrainerName: "Dr. Sunita Kulkarni",
      thumbnail: "https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&q=80&w=800",
      description: "Hands-on operational capacity building on dual-polarization S/C/X band Doppler weather radars. Learn reflectivity (Z), radial velocity (V), spectrum width (W), differential reflectivity (ZDR), specific differential phase (KDP), and convective cell tracking for urban flood & severe weather nowcasting.",
      prerequisites: ["Electromagnetic Wave Theory", "Basic Meteorological Observations"],
      enrolledTraineeIds: ["u_trainee_1", "u_trainee_2"],
      competenciesGained: ["Dual-Pol Signatures", "Mesocyclone Detection", "TITAN Cell Tracking", "QPE Estimation"],
      subjects: [
        {
          id: "sub_dwr_01",
          name: "Subject 1: Radar Hardware, Scan Strategies & Base Products",
          modules: [
            {
              id: "mod_dwr_01",
              title: "Module 1: PPI, RHI, MAX(Z) and Radial Velocity De-aliasing",
              duration: "6 Hours",
              materials: [
                {
                  id: "mat_dwr_01",
                  title: "Masterclass: Nyquist Velocity & Dual-PRF Algorithms",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "40 mins",
                  allowDownload: false
                },
                {
                  id: "mat_dwr_02",
                  title: "DWR Product Atlas (CAPPI, PACP, SRI, ETOP)",
                  type: "pdf",
                  url: "https://example.com/notes/dwr_product_atlas.pdf",
                  size: "8.7 MB",
                  allowDownload: true
                }
              ]
            }
          ]
        },
        {
          id: "sub_dwr_02",
          name: "Subject 2: Severe Storm Signatures & Hydrometeor Classification",
          modules: [
            {
              id: "mod_dwr_02",
              title: "Module 2: Hook Echo, BWER, Microbursts & Hail Core Detection",
              duration: "8 Hours",
              materials: [
                {
                  id: "mat_dwr_03",
                  title: "Lecture: Dual-Pol Fuzzy Logic Hydrometeor Classification (HCA)",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "60 mins",
                  allowDownload: false
                },
                {
                  id: "mat_dwr_04",
                  title: "Case Studies: Squall Line Analysis in Northern Plains",
                  type: "presentation",
                  url: "https://example.com/slides/squall_case_studies.pdf",
                  pages: 50,
                  allowDownload: true
                }
              ]
            }
          ]
        }
      ]
    },
    {
      id: "crs_cyc_103",
      code: "MOES-IMD-CYC-2025",
      title: "Tropical Cyclone Tracking, Intensity Estimation & Coastal Early Warning",
      category: "Synoptic & Marine Meteorology",
      level: "Advanced",
      duration: "5 Weeks (40 Hours)",
      creditHours: 3.5,
      department: "Cyclone Warning Division",
      leadTrainerId: "u_trainer_3",
      leadTrainerName: "Dr. Rajiv Roy",
      thumbnail: "https://images.unsplash.com/photo-1527482797697-8795b05a13fe?auto=format&fit=crop&q=80&w=800",
      description: "In-depth specialization for cyclone forecasters: Enhanced Dvorak Technique (CDO, Eye Pattern, Curved Band), scatterometer wind extraction, cyclone heat potential (TCHP), storm surge coupling, and SOPs for Multi-Hazard Disaster Warning.",
      prerequisites: ["Synoptic Chart Analysis", "Satellite Meteorology"],
      enrolledTraineeIds: ["u_trainee_2"],
      competenciesGained: ["Dvorak T-Number", "Storm Surge Inundation", "Cone of Uncertainty", "MoES Early Warning SOPs"],
      subjects: [
        {
          id: "sub_cyc_01",
          name: "Subject 1: Cyclogenesis & Advanced Dvorak Technique (ADT)",
          modules: [
            {
              id: "mod_cyc_01",
              title: "Module 1: Dvorak Rules for North Indian Ocean Basins",
              duration: "6 Hours",
              materials: [
                {
                  id: "mat_cyc_01",
                  title: "Video: Curved Band and Shear Pattern T-Number Computation",
                  type: "video",
                  url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
                  duration: "50 mins",
                  allowDownload: false
                }
              ]
            }
          ]
        }
      ]
    }
  ],

  // Question Bank strictly matching UI references in user screenshot
  questionBank: [
    {
      id: "qb_01",
      question: "Which of the following balances is fundamentally assumed in the Quasi-Geostrophic (QG) Omega equation to diagnose synoptic-scale vertical motion?",
      subjectId: "sub_nwp_01",
      subjectName: "Subject 1: Governing Equations & Atmospheric Dynamics",
      module: "Module 1",
      marks: 2,
      type: "MCQ",
      difficulty: "Medium",
      options: [
        "A. Hydrostatic and Geostrophic balance",
        "B. Cyclostrophic and Gradient wind balance",
        "C. Antitriptic and Thermal wind balance",
        "D. Anelastic and Incompressible balance"
      ],
      correctAnswer: 0,
      explanation: "The QG Omega equation combines the hydrostatic balance and geostrophic approximation with the thermodynamic energy equation to deduce vertical velocity (omega)."
    },
    {
      id: "qb_02",
      question: "In numerical grid modeling, what numerical instability criterion dictates the maximum allowable time step (dt) relative to grid spacing (dx) and wave velocity (c)?",
      subjectId: "sub_nwp_01",
      subjectName: "Subject 1: Governing Equations & Atmospheric Dynamics",
      module: "Module 2",
      marks: 2,
      type: "MCQ",
      difficulty: "Hard",
      options: [
        "A. Richardson Flux Number Criterion",
        "B. Courant-Friedrichs-Lewy (CFL) Condition (c * dt / dx <= 1)",
        "C. Prandtl Boundary Layer Limit",
        "D. Brunt-Väisälä Frequency Upper Bound"
      ],
      correctAnswer: 1,
      explanation: "The Courant-Friedrichs-Lewy (CFL) condition is mandatory for hyperbolic PDE convergence and stability in explicit numerical time-stepping schemes."
    },
    {
      id: "qb_03",
      question: "What dual-polarization radar parameter is most effective for distinguishing giant hail from heavy rain cores?",
      subjectId: "sub_dwr_01",
      subjectName: "Subject 1: Radar Hardware, Scan Strategies & Base Products",
      module: "Module 2",
      marks: 3,
      type: "MCQ",
      difficulty: "Hard",
      options: [
        "A. High Reflectivity (Z > 55 dBZ) paired with near-zero or negative Differential Reflectivity (ZDR < 0.5 dB)",
        "B. Low Copolar Correlation Coefficient (RhoHV > 0.99)",
        "C. Zero Radial Velocity (V = 0 m/s)",
        "D. Negative Specific Differential Phase (KDP < -5 deg/km)"
      ],
      correctAnswer: 0,
      explanation: "Tumbling hailstones appear spherical or vertically oriented on average, yielding very high Z (> 55 dBZ) but low ZDR (< 0.5 dB), whereas large rain drops flatten and produce high ZDR (> 3.0 dB)."
    },
    {
      id: "qb_04",
      question: "State the primary operational purpose of the Nyquist velocity equation in Doppler radar pulse repetition frequency (PRF) design.",
      subjectId: "sub_dwr_01",
      subjectName: "Subject 1: Radar Hardware, Scan Strategies & Base Products",
      module: "Module 1",
      marks: 4,
      type: "Descriptive",
      difficulty: "Medium",
      options: [],
      correctAnswer: null,
      explanation: "V_max = (lambda * PRF) / 4. It defines the unambiguous velocity threshold beyond which velocity aliasing occurs, creating the radar Doppler dilemma between range and velocity."
    },
    {
      id: "qb_05",
      question: "What characteristic Doppler velocity dipole signature indicates the presence of a mesocyclone or tornado vortex signature (TVS)?",
      subjectId: "sub_dwr_02",
      subjectName: "Subject 2: Severe Storm Signatures & Hydrometeor Classification",
      module: "Module 2",
      marks: 5,
      type: "MCQ",
      difficulty: "Hard",
      options: [
        "A. Adjacent inbound (negative) and outbound (positive) velocity maxima oriented azimuthally perpendicular to radar beam",
        "B. Uniform zero radial velocity across the entire storm echo",
        "C. Wide spectrum width in stratiform rain without velocity shear",
        "D. Maximum positive radial velocity at the storm top"
      ],
      correctAnswer: 0,
      explanation: "A cyclonic rotation appears as adjacent inbound and outbound velocity couplet with strong azimuthal shear."
    },
    {
      id: "qb_06",
      question: "According to the Dvorak Tropical Cyclone analysis technique, what does a Data T-number (DT) of T4.0 correspond to in terms of estimated Maximum Sustained Wind (MSW) in the North Indian Ocean?",
      subjectId: "sub_cyc_01",
      subjectName: "Subject 1: Cyclogenesis & Advanced Dvorak Technique (ADT)",
      module: "Module 1",
      marks: 2,
      type: "MCQ",
      difficulty: "Easy",
      options: [
        "A. 65 knots (Very Severe Cyclonic Storm)",
        "B. 34 knots (Cyclonic Storm)",
        "C. 48 knots (Severe Cyclonic Storm)",
        "D. 90 knots (Extremely Severe Cyclonic Storm)"
      ],
      correctAnswer: 0,
      explanation: "In the IMD Dvorak scale, T4.0 corresponds to an estimated central pressure drop of ~20 hPa and maximum sustained surface winds of approximately 65 knots."
    },
    {
      id: "qb_07",
      question: "Which water vapor absorption band channel on INSAT-3DR is central to diagnosing upper-tropospheric dry air intrusions into tropical cyclones?",
      subjectId: "sub_nwp_02",
      subjectName: "Subject 2: Data Assimilation & Satellite Radiance Ingestion",
      module: "Module 3",
      marks: 1,
      type: "MCQ",
      difficulty: "Easy",
      options: [
        "A. 6.7 to 7.1 micron Mid-Tropospheric Water Vapor Channel (WV)",
        "B. 0.65 micron Visible Channel (VIS)",
        "C. 3.9 micron Shortwave Infrared Channel (SWIR)",
        "D. 12.0 micron Thermal Split-Window (TIR-2)"
      ],
      correctAnswer: 0,
      explanation: "The 6.7-7.1 µm water vapor channel senses radiation emitted by water vapor in the 400-600 hPa layer, highlighting dry slot intrusions that weaken cyclonic cores."
    },
    {
      id: "qb_08",
      question: "Define the term 'Specific Differential Phase (KDP)' and explain why it is immune to radar partial beam blockage and rain attenuation.",
      subjectId: "sub_dwr_01",
      subjectName: "Subject 1: Radar Hardware, Scan Strategies & Base Products",
      module: "Module 1",
      marks: 4,
      type: "Descriptive",
      difficulty: "Hard",
      options: [],
      correctAnswer: null,
      explanation: "KDP is the range derivative of differential propagation phase (PhiDP). Because it depends on phase difference rather than received power amplitude, it is not degraded by attenuation or partial beam blockage."
    }
  ],

  // Scheduled Quizzes
  quizzes: [
    {
      id: "quiz_nwp_midterm",
      title: "Mid-Term Comprehensive Assessment: NWP Governing Equations & Data Assimilation",
      courseId: "crs_nwp_101",
      courseName: "Advanced Numerical Weather Prediction (NWP)",
      trainerId: "u_trainer_1",
      trainerName: "Dr. Amit Sengupta",
      department: "Numerical Weather Prediction Division",
      totalMarks: 20,
      passMarks: 12,
      durationMinutes: 45,
      // Time controls: show card immediately or at scheduled time
      scheduledStartTime: "2025-01-01T00:00:00.000Z", // Active now
      deadlineTime: "2026-12-31T23:59:59.000Z",
      status: "published", // "draft" | "scheduled" | "published" | "completed"
      isKioskModeRequired: true,
      questions: [
        {
          id: "q_01",
          question: "Which of the following balances is fundamentally assumed in the Quasi-Geostrophic (QG) Omega equation to diagnose synoptic-scale vertical motion?",
          marks: 2,
          type: "MCQ",
          module: "Module 1",
          difficulty: "Medium",
          options: [
            "Hydrostatic and Geostrophic balance",
            "Cyclostrophic and Gradient wind balance",
            "Antitriptic and Thermal wind balance",
            "Anelastic and Incompressible balance"
          ],
          correctAnswer: 0
        },
        {
          id: "q_02",
          question: "In numerical grid modeling, what numerical instability criterion dictates the maximum allowable time step (dt) relative to grid spacing (dx) and wave velocity (c)?",
          marks: 2,
          type: "MCQ",
          module: "Module 2",
          difficulty: "Hard",
          options: [
            "Richardson Flux Number Criterion",
            "Courant-Friedrichs-Lewy (CFL) Condition (c * dt / dx <= 1)",
            "Prandtl Boundary Layer Limit",
            "Brunt-Väisälä Frequency Upper Bound"
          ],
          correctAnswer: 1
        },
        {
          id: "q_03",
          question: "What is the primary role of the Background Error Covariance matrix (B-Matrix) in 3D-Var Data Assimilation?",
          marks: 3,
          type: "MCQ",
          module: "Module 3",
          difficulty: "Hard",
          options: [
            "To filter high-frequency acoustic waves only",
            "To spread observation increments spatially and maintain physical balances (e.g. Geostrophic)",
            "To calculate surface albedo over oceanic grids",
            "To simulate microphysical ice nucleation rates"
          ],
          correctAnswer: 1
        },
        {
          id: "q_04",
          question: "Which water vapor absorption band channel on INSAT-3DR is central to diagnosing upper-tropospheric dry air intrusions into tropical cyclones?",
          marks: 3,
          type: "MCQ",
          module: "Module 3",
          difficulty: "Easy",
          options: [
            "6.7 to 7.1 micron Mid-Tropospheric Water Vapor Channel (WV)",
            "0.65 micron Visible Channel (VIS)",
            "3.9 micron Shortwave Infrared Channel (SWIR)",
            "12.0 micron Thermal Split-Window (TIR-2)"
          ],
          correctAnswer: 0
        },
        {
          id: "q_05",
          question: "In ensemble forecasting systems (EPS), what metric quantitatively measures the dispersion of ensemble members relative to ensemble mean forecast error?",
          marks: 5,
          type: "MCQ",
          module: "Module 2",
          difficulty: "Hard",
          options: [
            "Spread-Skill Relationship (Ensemble Spread vs RMSE of Mean)",
            "Brier Score Calibration Slope only",
            "Continuous Ranked Probability Score (CRPS) baseline",
            "Talagrand Rank Histogram Uniformity Index"
          ],
          correctAnswer: 0
        },
        {
          id: "q_06",
          question: "What physical parameterization in the WRF model is responsible for resolving sub-grid scale deep convective updrafts and downdrafts in coarse resolution (> 10 km) simulations?",
          marks: 5,
          type: "MCQ",
          module: "Module 1",
          difficulty: "Medium",
          options: [
            "Cumulus Parameterization Scheme (e.g. Kain-Fritsch / Betts-Miller-Janjic)",
            "Microphysics Scheme (e.g. WSM6)",
            "Monin-Obukhov Surface Layer Physics",
            "RRTMG Longwave Radiation Scheme"
          ],
          correctAnswer: 0
        }
      ]
    },
    {
      id: "quiz_dwr_severe",
      title: "Operational Assessment: Doppler Radar Dual-Pol Signatures & Nowcasting",
      courseId: "crs_dwr_102",
      courseName: "Doppler Weather Radar (DWR) Operational Data Interpretation",
      trainerId: "u_trainer_2",
      trainerName: "Dr. Sunita Kulkarni",
      department: "Radar & Satellite Meteorology Division",
      totalMarks: 20,
      passMarks: 12,
      durationMinutes: 30,
      scheduledStartTime: "2025-01-01T00:00:00.000Z",
      deadlineTime: "2026-12-31T23:59:59.000Z",
      status: "published",
      isKioskModeRequired: true,
      questions: [
        {
          id: "q_dwr_01",
          question: "What dual-polarization radar parameter is most effective for distinguishing giant hail from heavy rain cores?",
          marks: 5,
          type: "MCQ",
          module: "Module 2",
          difficulty: "Hard",
          options: [
            "High Reflectivity (Z > 55 dBZ) paired with near-zero or negative Differential Reflectivity (ZDR < 0.5 dB)",
            "Low Copolar Correlation Coefficient (RhoHV > 0.99)",
            "Zero Radial Velocity (V = 0 m/s)",
            "Negative Specific Differential Phase (KDP < -5 deg/km)"
          ],
          correctAnswer: 0
        },
        {
          id: "q_dwr_02",
          question: "What characteristic Doppler velocity dipole signature indicates the presence of a mesocyclone or tornado vortex signature (TVS)?",
          marks: 5,
          type: "MCQ",
          module: "Module 2",
          difficulty: "Hard",
          options: [
            "Adjacent inbound (negative) and outbound (positive) velocity maxima oriented azimuthally perpendicular to radar beam",
            "Uniform zero radial velocity across the entire storm echo",
            "Wide spectrum width in stratiform rain without velocity shear",
            "Maximum positive radial velocity at the storm top"
          ],
          correctAnswer: 0
        },
        {
          id: "q_dwr_03",
          question: "In dual-PRF radar velocity de-aliasing, what is the unambiguous range and velocity product determined by?",
          marks: 5,
          type: "MCQ",
          module: "Module 1",
          difficulty: "Medium",
          options: [
            "The Doppler Dilemma: R_max * V_max = (c * lambda) / 8",
            "The Radar Equation constant C_rad only",
            "Antenna beamwidth theta_3dB squared",
            "Noise equivalent power (NEP)"
          ],
          correctAnswer: 0
        },
        {
          id: "q_dwr_04",
          question: "What does a significant drop in Copolar Correlation Coefficient (RhoHV < 0.80) inside an intense convective echo reliably indicate?",
          marks: 5,
          type: "MCQ",
          module: "Module 2",
          difficulty: "Medium",
          options: [
            "Non-meteorological scatterers or Tornado Debris Signature (TDS) / giant wet hail mixture",
            "Pure spherical drizzle drops",
            "Clean stratiform snow crystals",
            "Absence of turbulent updrafts"
          ],
          correctAnswer: 0
        }
      ]
    }
  ],

  // Quiz Submissions & Evaluations
  quizSubmissions: [
    {
      id: "subm_01",
      quizId: "quiz_nwp_midterm",
      traineeId: "u_trainee_1",
      traineeName: "Rahul Sharma",
      traineeEmail: "rahul.sharma@imd.gov.in",
      answers: {
        "q_01": 0,
        "q_02": 1,
        "q_03": 1,
        "q_04": 0,
        "q_05": 0,
        "q_06": 0
      },
      score: 20,
      totalMarks: 20,
      percentage: 100,
      passed: true,
      timeTakenSeconds: 1420,
      tabSwitchCount: 0,
      submittedAt: "2025-02-10T14:35:22.000Z",
      gradedBy: "auto",
      certificateGenerated: true,
      certificateId: "MOES-IMD-CERT-2025-0981"
    },
    {
      id: "subm_02",
      quizId: "quiz_dwr_severe",
      traineeId: "u_trainee_2",
      traineeName: "Priya Varma",
      traineeEmail: "priya.varma@imd.gov.in",
      answers: {
        "q_dwr_01": 0,
        "q_dwr_02": 0,
        "q_dwr_03": 0,
        "q_dwr_04": 0
      },
      score: 20,
      totalMarks: 20,
      percentage: 100,
      passed: true,
      timeTakenSeconds: 980,
      tabSwitchCount: 1,
      submittedAt: "2025-02-12T11:20:10.000Z",
      gradedBy: "auto",
      certificateGenerated: true,
      certificateId: "MOES-IMD-CERT-2025-1104"
    }
  ],

  // Competency Mapping Matrix (Matches competencies to trainers and courses)
  competencyFramework: [
    {
      id: "comp_01",
      name: "Numerical Weather Prediction & Data Assimilation",
      category: "Atmospheric Modeling",
      description: "Execution of dynamical atmospheric models, grid parameterization, boundary conditions, and assimilation of radar/satellite observations.",
      requiredLevel: "Expert",
      matchedTrainers: [
        { trainerId: "u_trainer_1", name: "Dr. Amit Sengupta", matchScore: 98, experience: "18 Years", verifiedCertificates: 6 },
        { trainerId: "u_trainer_3", name: "Dr. Rajiv Roy", matchScore: 72, experience: "12 Years", verifiedCertificates: 3 }
      ],
      assignedCourses: ["crs_nwp_101"],
      suggestedTrainers: ["Dr. Amit Sengupta", "Dr. S. C. Bhan (External Advisor)"]
    },
    {
      id: "comp_02",
      name: "Doppler Weather Radar (DWR) & Dual-Polarization Analysis",
      category: "Remote Sensing",
      description: "Interpretation of polarimetric moments, hydrometeor classification, severe storm nowcasting, and QPE algorithms.",
      requiredLevel: "Expert",
      matchedTrainers: [
        { trainerId: "u_trainer_2", name: "Dr. Sunita Kulkarni", matchScore: 96, experience: "14 Years", verifiedCertificates: 5 },
        { trainerId: "u_trainer_1", name: "Dr. Amit Sengupta", matchScore: 65, experience: "18 Years", verifiedCertificates: 2 }
      ],
      assignedCourses: ["crs_dwr_102"],
      suggestedTrainers: ["Dr. Sunita Kulkarni", "Dr. D. Pradhan (Former DWR Head)"]
    },
    {
      id: "comp_03",
      name: "Tropical Cyclogenesis, Dvorak Technique & Storm Surge",
      category: "Marine & Synoptic",
      description: "Tracking tropical systems, Dvorak T-number assignment, ocean heat content estimation, and coastal inundation modeling.",
      requiredLevel: "Expert",
      matchedTrainers: [
        { trainerId: "u_trainer_3", name: "Dr. Rajiv Roy", matchScore: 95, experience: "12 Years", verifiedCertificates: 4 }
      ],
      assignedCourses: ["crs_cyc_103"],
      suggestedTrainers: ["Dr. Rajiv Roy", "Dr. Ananda Kumar Das"]
    },
    {
      id: "comp_04",
      name: "Agrometeorology & Crop Weather Advisory",
      category: "Applied Meteorology",
      description: "Gramin Krishi Mausam Sewa (GKMS) advisory formulation, drought indices, evapotranspiration models.",
      requiredLevel: "Intermediate",
      matchedTrainers: [
        { trainerId: "u_trainer_pending", name: "Dr. Meenakshi Sundaram", matchScore: 92, experience: "9 Years", verifiedCertificates: 4 }
      ],
      assignedCourses: [],
      suggestedTrainers: ["Dr. Meenakshi Sundaram (Pending Approval)", "Dr. K. K. Singh"]
    }
  ],

  // Announcements & Homepage Highlights published by Admin
  announcements: [
    {
      id: "ann_01",
      title: "MoES Launches Digital Capacity Building Initiative for All Regional Meteorological Centres",
      category: "National Directive",
      date: "2025-02-14",
      urgent: true,
      content: "The Ministry of Earth Sciences mandates all Scientific Assistants and Trainee Meteorologists to complete Level-1 Competency Assessments on the CAPACITY CONNECT portal by Q2 2025.",
      author: "Director General Office, New Delhi"
    },
    {
      id: "ann_02",
      title: "New Doppler Weather Radar (DWR) Dual-Pol Certification Cohort Announced",
      category: "Training Cohort",
      date: "2025-02-10",
      urgent: false,
      content: "Enrollments are now open for the 4-week intensive training on Dual-Polarization radar data interpretation led by Dr. Sunita Kulkarni.",
      author: "IMD Training Centre Pune"
    },
    {
      id: "ann_03",
      title: "Achievement: IMD Completes 10,000 Trainee Certifications Across 36 State Meteorological Offices",
      category: "Milestone",
      date: "2025-02-01",
      urgent: false,
      content: "National capacity building in weather forecasting accuracy reaches record high with 94.8% assessment pass rate.",
      author: "MoES Capacity Cell"
    }
  ],

  // Course / Trainer Feedback
  feedbacks: [
    {
      id: "fb_01",
      courseId: "crs_nwp_101",
      traineeId: "u_trainee_1",
      traineeName: "Rahul Sharma",
      trainerRating: 5,
      contentRating: 5,
      relevanceRating: 5,
      comment: "Outstanding coverage of WRF boundary conditions and data assimilation! The hands-on lab notes and videos directly improved our operational forecasting shifts.",
      createdAt: "2025-02-11T16:00:00.000Z"
    },
    {
      id: "fb_02",
      courseId: "crs_dwr_102",
      traineeId: "u_trainee_2",
      traineeName: "Priya Varma",
      trainerRating: 5,
      contentRating: 4.8,
      relevanceRating: 5,
      comment: "Dr. Sunita Kulkarni's hydrometeor classification lecture helped us accurately diagnose a severe squall line over the east coast.",
      createdAt: "2025-02-13T09:30:00.000Z"
    }
  ]
};
