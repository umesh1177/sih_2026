import React, { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  HelpCircle, 
  ClipboardList, 
  Layers, 
  BarChart3, 
  ShieldCheck, 
  BellRing, 
  UserCheck, 
  ChevronDown, 
  Sparkles,
  Award,
  GraduationCap,
  Building2,
  Compass
} from "lucide-react";

export const Sidebar = ({ activeTab, setActiveTab }) => {
  const { currentUser, demoAccounts, switchAccount } = useAuth();
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);

  // Role based navigation links
  const getNavItems = () => {
    const baseItems = [
      { id: "dashboard", label: "Executive Dashboard", icon: LayoutDashboard },
      { id: "courses", label: "Course Catalog", icon: BookOpen },
      { id: "subjects", label: "Subject Modules", icon: Layers },
    ];

    if (currentUser?.role === "trainer") {
      return [
        ...baseItems,
        { id: "questions", label: "Question Bank", icon: HelpCircle },
        { id: "quizzes", label: "Scheduled Assessments", icon: ClipboardList },
        { id: "analytics", label: "Performance Analytics", icon: BarChart3 },
      ];
    }

    if (currentUser?.role === "admin") {
      return [
        ...baseItems,
        { id: "approvals", label: "Officer Approvals", icon: UserCheck },
        { id: "competency", label: "Competency Matrix", icon: Compass },
        { id: "questions", label: "Question Bank", icon: HelpCircle },
        { id: "quizzes", label: "Assessments Engine", icon: ClipboardList },
        { id: "announcements", label: "National Broadcasts", icon: BellRing },
        { id: "analytics", label: "Platform Analytics", icon: BarChart3 },
      ];
    }

    // Trainee view
    return [
      ...baseItems,
      { id: "my-learning", label: "My Enrolled Courses", icon: GraduationCap },
      { id: "trainee-quizzes", label: "My Assessments", icon: ClipboardList },
      { id: "certificates", label: "Certified Credentials", icon: Award },
      { id: "profile", label: "Officer Profile", icon: FileText },
      { id: "analytics", label: "Competency Radar", icon: BarChart3 },
    ];
  };

  const navItems = getNavItems();

  return (
    <aside className="w-64 bg-[#0a2558] text-white flex flex-col h-screen select-none shrink-0 shadow-2xl relative z-30 border-r border-white/10">
      {/* Brand Header matching Screenshot 1 & 3 with premium glow */}
      <div className="p-5 border-b border-white/10 flex items-center gap-3.5 bg-gradient-to-b from-white/10 to-transparent">
        <div className="w-10 h-10 rounded-2xl bg-white text-[#0a2558] flex items-center justify-center font-black text-xl tracking-wider shadow-lg">
          Q
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <h1 className="font-extrabold text-base tracking-tight text-white">QuizPortal</h1>
            <span className="px-1.5 py-0.2 text-[8px] font-black rounded bg-blue-400/30 text-blue-200 uppercase">
              PRO
            </span>
          </div>
          <p className="text-[10px] text-blue-200/80 font-medium tracking-wide">MoES Capacity Connect</p>
        </div>
      </div>

      {/* Role Badge Indicator */}
      <div className="px-5 py-2.5 bg-black/25 border-b border-white/5 flex items-center justify-between text-xs">
        <span className="text-blue-200/70 text-[11px] font-medium">Logged Role:</span>
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-white/20 text-white shadow-inner">
          {currentUser?.role}
        </span>
      </div>

      {/* Navigation List matching Screenshot 1 & 3 Active Pill Style */}
      <nav className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl font-medium text-xs transition-all duration-200 text-left ${
                isActive
                  ? "bg-white text-[#0a2558] font-black shadow-lg transform translate-x-1"
                  : "text-blue-100/80 hover:bg-white/10 hover:text-white"
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-[#0a2558]" : "text-blue-300"}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Switch Role / Account Selector Drawer */}
      {showRoleDropdown && (
        <div className="absolute bottom-20 left-3 right-3 bg-white text-slate-800 rounded-2xl shadow-2xl p-2.5 border border-slate-200 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
          <div className="text-[10px] font-bold text-slate-400 px-3 py-1 uppercase tracking-wider">
            Switch Test Persona
          </div>
          <div className="space-y-1 mt-1">
            {demoAccounts.map((acc, index) => (
              <button
                key={index}
                onClick={() => {
                  switchAccount(acc);
                  setShowRoleDropdown(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex flex-col transition-colors ${
                  currentUser?.email === acc.email 
                    ? "bg-blue-50 text-[#0a2558] border border-blue-200" 
                    : "hover:bg-slate-100 text-slate-700"
                }`}
              >
                <span>{acc.label}</span>
                <span className="text-[10px] text-slate-400 font-normal">{acc.email}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* User Footer matching Screenshot 1 & 3 bottom card */}
      <div className="p-3 border-t border-white/10 bg-black/20">
        <button
          onClick={() => setShowRoleDropdown(!showRoleDropdown)}
          className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-white/10 transition-colors text-left group"
        >
          <div className="flex items-center gap-2.5 overflow-hidden">
            <img
              src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250"}
              alt="User"
              className="w-8 h-8 rounded-xl object-cover ring-2 ring-white/20 shrink-0 shadow-sm"
            />
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-white truncate group-hover:text-blue-200 transition-colors">
                {currentUser?.name || "Institute User"}
              </p>
              <p className="text-[10px] text-blue-200/70 truncate">
                {currentUser?.email || "user@imd.gov.in"}
              </p>
            </div>
          </div>
          <ChevronDown className={`w-4 h-4 text-blue-200/70 shrink-0 transition-transform ${showRoleDropdown ? "rotate-180" : ""}`} />
        </button>
      </div>
    </aside>
  );
};
