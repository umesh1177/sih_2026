// In-memory persistent data store for CAPACITY CONNECT
import { initialData } from "../data/mockData.js";
import { v4 as uuidv4 } from "uuid";

class DatabaseStore {
  constructor() {
    this.users = [...initialData.users];
    this.courses = JSON.parse(JSON.stringify(initialData.courses));
    this.questionBank = [...initialData.questionBank];
    this.quizzes = JSON.parse(JSON.stringify(initialData.quizzes));
    this.quizSubmissions = [...initialData.quizSubmissions];
    this.competencyFramework = JSON.parse(JSON.stringify(initialData.competencyFramework));
    this.announcements = [...initialData.announcements];
    this.feedbacks = [...initialData.feedbacks];
  }

  // --- Users & Auth ---
  findUserByEmail(email) {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  findUserById(id) {
    return this.users.find(u => u.id === id);
  }

  createUser(userData) {
    const newUser = {
      id: userData.id || `u_${userData.role}_${uuidv4().substring(0, 8)}`,
      name: userData.name,
      email: userData.email,
      role: userData.role || "trainee",
      department: userData.department || "India Meteorological Department",
      designation: userData.designation || "Officer",
      status: userData.role === "admin" ? "approved" : (userData.status || "pending"),
      interests: userData.interests || [],
      skills: userData.skills || [],
      qualifications: userData.qualifications || "",
      experience: userData.experience || "",
      specialization: userData.specialization || [],
      certificates: userData.certificates || [],
      bio: userData.bio || "",
      avatar: userData.avatar || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250`,
      createdAt: new Date().toISOString()
    };
    this.users.push(newUser);
    return newUser;
  }

  updateUser(id, updates) {
    const index = this.users.findIndex(u => u.id === id);
    if (index !== -1) {
      this.users[index] = { ...this.users[index], ...updates };
      return this.users[index];
    }
    return null;
  }

  getPendingUsers() {
    return this.users.filter(u => u.status === "pending");
  }

  approveUser(id, approved = true, notes = "") {
    const user = this.findUserById(id);
    if (user) {
      user.status = approved ? "approved" : "rejected";
      user.approvalNotes = notes;
      return user;
    }
    return null;
  }

  // --- Courses ---
  getCourses() {
    return this.courses;
  }

  getCourseById(id) {
    return this.courses.find(c => c.id === id);
  }

  createCourse(courseData) {
    const newCourse = {
      id: courseData.id || `crs_${uuidv4().substring(0, 8)}`,
      code: courseData.code || `MOES-IMD-${Math.floor(100 + Math.random() * 900)}`,
      title: courseData.title,
      category: courseData.category || "Meteorological Sciences",
      level: courseData.level || "Intermediate",
      duration: courseData.duration || "4 Weeks",
      creditHours: courseData.creditHours || 3,
      department: courseData.department || "IMD Headquarters",
      leadTrainerId: courseData.leadTrainerId || "",
      leadTrainerName: courseData.leadTrainerName || "Assigned Senior Scientist",
      thumbnail: courseData.thumbnail || "https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&q=80&w=800",
      description: courseData.description || "",
      prerequisites: courseData.prerequisites || [],
      enrolledTraineeIds: courseData.enrolledTraineeIds || [],
      competenciesGained: courseData.competenciesGained || [],
      subjects: courseData.subjects || []
    };
    this.courses.unshift(newCourse);
    return newCourse;
  }

  enrollTrainee(courseId, traineeId) {
    const course = this.getCourseById(courseId);
    if (course) {
      if (!course.enrolledTraineeIds) course.enrolledTraineeIds = [];
      if (!course.enrolledTraineeIds.includes(traineeId)) {
        course.enrolledTraineeIds.push(traineeId);
      }
      return course;
    }
    return null;
  }

  addMaterialToModule(courseId, subjectId, moduleId, materialData) {
    const course = this.getCourseById(courseId);
    if (!course) return null;
    const subject = course.subjects.find(s => s.id === subjectId);
    if (!subject) return null;
    const mod = subject.modules.find(m => m.id === moduleId);
    if (!mod) return null;

    const newMaterial = {
      id: materialData.id || `mat_${uuidv4().substring(0, 8)}`,
      title: materialData.title,
      type: materialData.type || "pdf",
      url: materialData.url || "https://example.com/material.pdf",
      duration: materialData.duration,
      pages: materialData.pages,
      size: materialData.size || "3.5 MB",
      allowDownload: materialData.allowDownload !== false // Default true or toggleable
    };
    mod.materials.push(newMaterial);
    return newMaterial;
  }

  // --- Question Bank ---
  getQuestions(filter = {}) {
    let result = [...this.questionBank];
    if (filter.subjectId) {
      result = result.filter(q => q.subjectId === filter.subjectId);
    }
    if (filter.type) {
      result = result.filter(q => q.type.toLowerCase() === filter.type.toLowerCase());
    }
    if (filter.difficulty) {
      result = result.filter(q => q.difficulty.toLowerCase() === filter.difficulty.toLowerCase());
    }
    if (filter.search) {
      const qLower = filter.search.toLowerCase();
      result = result.filter(q => q.question.toLowerCase().includes(qLower));
    }
    return result;
  }

  createQuestion(questionData) {
    const newQ = {
      id: questionData.id || `qb_${uuidv4().substring(0, 8)}`,
      question: questionData.question,
      subjectId: questionData.subjectId || "sub_nwp_01",
      subjectName: questionData.subjectName || "Atmospheric Dynamics",
      module: questionData.module || "Module 1",
      marks: Number(questionData.marks) || 2,
      type: questionData.type || "MCQ",
      difficulty: questionData.difficulty || "Medium",
      options: questionData.options || [],
      correctAnswer: questionData.correctAnswer !== undefined ? Number(questionData.correctAnswer) : 0,
      explanation: questionData.explanation || ""
    };
    this.questionBank.unshift(newQ);
    return newQ;
  }

  duplicateQuestion(id) {
    const q = this.questionBank.find(item => item.id === id);
    if (q) {
      const cloned = {
        ...q,
        id: `qb_${uuidv4().substring(0, 8)}`,
        question: `${q.question} (Copy)`
      };
      this.questionBank.unshift(cloned);
      return cloned;
    }
    return null;
  }

  deleteQuestion(id) {
    const initialLen = this.questionBank.length;
    this.questionBank = this.questionBank.filter(q => q.id !== id);
    return this.questionBank.length < initialLen;
  }

  // --- Quizzes ---
  getQuizzes() {
    return this.quizzes;
  }

  getQuizById(id) {
    return this.quizzes.find(q => q.id === id);
  }

  createQuiz(quizData) {
    const newQuiz = {
      id: quizData.id || `quiz_${uuidv4().substring(0, 8)}`,
      title: quizData.title,
      courseId: quizData.courseId,
      courseName: quizData.courseName,
      trainerId: quizData.trainerId,
      trainerName: quizData.trainerName,
      department: quizData.department || "India Meteorological Department",
      totalMarks: Number(quizData.totalMarks) || 20,
      passMarks: Number(quizData.passMarks) || 10,
      durationMinutes: Number(quizData.durationMinutes) || 30,
      scheduledStartTime: quizData.scheduledStartTime || new Date().toISOString(),
      deadlineTime: quizData.deadlineTime || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      status: quizData.status || "published",
      isKioskModeRequired: true,
      questions: quizData.questions || []
    };
    this.quizzes.unshift(newQuiz);
    return newQuiz;
  }

  // --- Submissions & Auto-Grading ---
  submitQuiz(submissionData) {
    const quiz = this.getQuizById(submissionData.quizId);
    if (!quiz) throw new Error("Quiz not found");

    let totalScore = 0;
    const answers = submissionData.answers || {};

    // Auto-calculate score
    quiz.questions.forEach(q => {
      const selected = answers[q.id];
      if (selected !== undefined && selected === q.correctAnswer) {
        totalScore += q.marks || 2;
      }
    });

    const totalMarks = quiz.totalMarks || quiz.questions.reduce((acc, q) => acc + (q.marks || 2), 0);
    const percentage = Math.round((totalScore / (totalMarks || 1)) * 100);
    const passed = totalScore >= (quiz.passMarks || (totalMarks * 0.5));

    const submission = {
      id: `subm_${uuidv4().substring(0, 8)}`,
      quizId: quiz.id,
      quizTitle: quiz.title,
      courseId: quiz.courseId,
      traineeId: submissionData.traineeId,
      traineeName: submissionData.traineeName,
      traineeEmail: submissionData.traineeEmail,
      answers,
      score: totalScore,
      totalMarks,
      percentage,
      passed,
      timeTakenSeconds: submissionData.timeTakenSeconds || 600,
      tabSwitchCount: submissionData.tabSwitchCount || 0,
      submittedAt: new Date().toISOString(),
      gradedBy: "auto",
      certificateGenerated: passed,
      certificateId: passed ? `MOES-IMD-CERT-2025-${Math.floor(1000 + Math.random() * 9000)}` : null
    };

    this.quizSubmissions.unshift(submission);
    return submission;
  }

  getSubmissionsForQuiz(quizId) {
    return this.quizSubmissions.filter(s => s.quizId === quizId);
  }

  getSubmissionsForTrainee(traineeId) {
    return this.quizSubmissions.filter(s => s.traineeId === traineeId);
  }

  // --- Competency Mapping ---
  getCompetencyMatrix() {
    return this.competencyFramework;
  }

  assignTrainerToCompetency(competencyId, trainerId, trainerName) {
    const comp = this.competencyFramework.find(c => c.id === competencyId);
    if (comp) {
      if (!comp.suggestedTrainers.includes(trainerName)) {
        comp.suggestedTrainers.push(trainerName);
      }
      return comp;
    }
    return null;
  }

  // --- Announcements & Feedback ---
  getAnnouncements() {
    return this.announcements;
  }

  createAnnouncement(annData) {
    const ann = {
      id: `ann_${uuidv4().substring(0, 8)}`,
      title: annData.title,
      category: annData.category || "General",
      date: new Date().toISOString().split("T")[0],
      urgent: !!annData.urgent,
      content: annData.content,
      author: annData.author || "MoES Directorate"
    };
    this.announcements.unshift(ann);
    return ann;
  }

  getFeedbacks(courseId) {
    if (courseId) return this.feedbacks.filter(f => f.courseId === courseId);
    return this.feedbacks;
  }

  addFeedback(fbData) {
    const fb = {
      id: `fb_${uuidv4().substring(0, 8)}`,
      courseId: fbData.courseId,
      traineeId: fbData.traineeId,
      traineeName: fbData.traineeName,
      trainerRating: Number(fbData.trainerRating) || 5,
      contentRating: Number(fbData.contentRating) || 5,
      relevanceRating: Number(fbData.relevanceRating) || 5,
      comment: fbData.comment || "",
      createdAt: new Date().toISOString()
    };
    this.feedbacks.unshift(fb);
    return fb;
  }
}

export const db = new DatabaseStore();
