import { db } from "../store/dbStore.js";

export const login = (req, res) => {
  try {
    const { email, role } = req.body;
    if (!email) {
      return res.status(400).json({ success: false, message: "Email is required" });
    }

    let user = db.findUserByEmail(email);
    if (!user) {
      // Auto register demo user if not existing
      user = db.createUser({
        name: email.split("@")[0].replace(".", " ").toUpperCase(),
        email,
        role: role || "trainee",
        status: role === "admin" ? "approved" : "approved"
      });
    }

    return res.json({
      success: true,
      message: "Login successful",
      user,
      token: "demo-jwt-token-" + user.id
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const register = (req, res) => {
  try {
    const { name, email, role, department, designation, qualifications, experience, interests, skills, specialization, certificates, bio } = req.body;
    
    if (!email || !name) {
      return res.status(400).json({ success: false, message: "Name and Email are required" });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ success: false, message: "User with this email already exists. Please login." });
    }

    const newUser = db.createUser({
      name,
      email,
      role: role || "trainee",
      department,
      designation,
      qualifications,
      experience,
      interests: Array.isArray(interests) ? interests : (interests ? interests.split(",").map(s => s.trim()) : []),
      skills: Array.isArray(skills) ? skills : (skills ? skills.split(",").map(s => s.trim()) : []),
      specialization: Array.isArray(specialization) ? specialization : (specialization ? specialization.split(",").map(s => s.trim()) : []),
      certificates: certificates || [],
      bio: bio || "",
      status: role === "admin" ? "approved" : "pending"
    });

    return res.status(201).json({
      success: true,
      message: role === "admin" ? "Admin registered" : "Registration submitted! Your profile is pending administrative approval.",
      user: newUser,
      token: "demo-jwt-token-" + newUser.id
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const getProfile = (req, res) => {
  try {
    const { id } = req.params;
    const user = db.findUserById(id);
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    return res.json({ success: true, user });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const updateProfile = (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const updated = db.updateUser(id, updates);
    if (!updated) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    return res.json({ success: true, message: "Profile updated successfully", user: updated });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

export const submitProfileForApproval = (req, res) => {
  try {
    const { id } = req.params;
    const updated = db.updateUser(id, { status: "pending", submittedAt: new Date().toISOString() });
    if (!updated) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    return res.json({ success: true, message: "Profile submitted for administrative verification and approval!", user: updated });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};
