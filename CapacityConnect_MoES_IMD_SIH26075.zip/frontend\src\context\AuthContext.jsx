import React, { createContext, useContext, useState, useEffect } from "react";
import { api } from "../services/api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  // Pre-seed with default logged in demo user (Trainer or Trainee or Admin)
  const [currentUser, setCurrentUser] = useState({
    id: "u_trainer_1",
    name: "Dr. Amit Sengupta",
    email: "amit.sengupta@imd.gov.in",
    role: "trainer",
    department: "Numerical Weather Prediction Division, New Delhi",
    designation: "Scientist 'F' & Senior Meteorologist",
    specialization: ["Numerical Weather Prediction", "WRF / GFS Modeling", "Ensemble Prediction"],
    experienceYears: 18,
    status: "approved",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250"
  });

  const [loading, setLoading] = useState(false);

  // Demo Fast Switcher Accounts for Judges & Reviewers
  const demoAccounts = [
    {
      role: "trainer",
      label: "Trainer (Dr. Amit Sengupta - NWP)",
      email: "amit.sengupta@imd.gov.in",
      user: {
        id: "u_trainer_1",
        name: "Dr. Amit Sengupta",
        email: "amit.sengupta@imd.gov.in",
        role: "trainer",
        department: "Numerical Weather Prediction Division, New Delhi",
        designation: "Scientist 'F' & Senior Meteorologist",
        specialization: ["Numerical Weather Prediction", "WRF / GFS Modeling", "Ensemble Prediction"],
        experienceYears: 18,
        status: "approved",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250"
      }
    },
    {
      role: "trainee",
      label: "Trainee (Rahul Sharma - Scientist 'B')",
      email: "rahul.sharma@imd.gov.in",
      user: {
        id: "u_trainee_1",
        name: "Rahul Sharma",
        email: "rahul.sharma@imd.gov.in",
        role: "trainee",
        department: "Meteorological Centre, Jaipur",
        designation: "Scientist 'B' (Trainee)",
        status: "approved",
        interests: ["NWP Models", "Satellite Imagery", "Severe Weather Warnings"],
        skills: ["Python for Meteorology", "Synoptic Analysis", "QGIS", "Data Assimilation"],
        qualifications: "M.Sc. Physics (University of Rajasthan), Advanced PG Diploma in Meteorology",
        experience: "2 years as Trainee Scientific Assistant at IMD Jaipur Field Station.",
        certificates: [
          { title: "Basic Meteorological Forecaster (BMF)", issuer: "IMD Training Centre Pune", year: "2024" }
        ],
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250"
      }
    },
    {
      role: "trainee_pending",
      label: "Trainee (Aniket Deshmukh - Pending Approval)",
      email: "aniket.d@imd.gov.in",
      user: {
        id: "u_trainee_pending",
        name: "Aniket Deshmukh",
        email: "aniket.d@imd.gov.in",
        role: "trainee",
        department: "Regional Meteorological Centre, Mumbai",
        designation: "Scientific Assistant Grade-II",
        status: "pending",
        interests: ["Urban Flood Forecasting", "Nowcasting", "Doppler Radar"],
        skills: ["Surface Observations", "AWS Data Analysis"],
        qualifications: "B.Sc. Physics (Mumbai University)",
        experience: "1 year field station maintenance.",
        certificates: [],
        avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&q=80&w=250"
      }
    },
    {
      role: "admin",
      label: "Admin (Director General Admin)",
      email: "admin@imd.gov.in",
      user: {
        id: "u_admin_1",
        name: "Dr. Mrutyunjay Mohapatra",
        email: "admin@imd.gov.in",
        role: "admin",
        department: "Directorate General of Meteorology, New Delhi",
        designation: "Director General & Chief Admin",
        status: "approved",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250"
      }
    }
  ];

  const switchAccount = (accountObj) => {
    setCurrentUser(accountObj.user);
  };

  const login = async (email, role) => {
    setLoading(true);
    try {
      const res = await api.login(email, role);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        return { success: true };
      }
      return { success: false, message: res.message };
    } catch (err) {
      return { success: false, message: err.message };
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData) => {
    setLoading(true);
    try {
      const res = await api.register(userData);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        return { success: true, message: res.message, user: res.user };
      }
      return { success: false, message: res.message };
    } catch (err) {
      return { success: false, message: err.message };
    } finally {
      setLoading(false);
    }
  };

  const refreshProfile = async () => {
    if (!currentUser?.id) return;
    try {
      const res = await api.getProfile(currentUser.id);
      if (res.success && res.user) {
        setCurrentUser(res.user);
      }
    } catch (err) {
      console.error("Profile refresh failed:", err);
    }
  };

  const logout = () => {
    // Switch to trainee default or reset
    setCurrentUser(demoAccounts[0].user);
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      setCurrentUser,
      demoAccounts,
      switchAccount,
      login,
      register,
      refreshProfile,
      logout,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
