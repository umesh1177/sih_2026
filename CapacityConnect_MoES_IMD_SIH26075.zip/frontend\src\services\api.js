const API_BASE_URL = "http://localhost:5000/api";

export const api = {
  // Auth & Profile
  login: async (email, role) => {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, role })
    });
    return res.json();
  },

  register: async (userData) => {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData)
    });
    return res.json();
  },

  getProfile: async (id) => {
    const res = await fetch(`${API_BASE_URL}/users/profile/${id}`);
    return res.json();
  },

  updateProfile: async (id, data) => {
    const res = await fetch(`${API_BASE_URL}/users/profile/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  submitProfileForApproval: async (id) => {
    const res = await fetch(`${API_BASE_URL}/users/profile/${id}/submit-approval`, {
      method: "POST"
    });
    return res.json();
  },

  // Courses & Learning Materials
  getCourses: async () => {
    const res = await fetch(`${API_BASE_URL}/courses`);
    return res.json();
  },

  getCourseById: async (id) => {
    const res = await fetch(`${API_BASE_URL}/courses/${id}`);
    return res.json();
  },

  createCourse: async (courseData) => {
    const res = await fetch(`${API_BASE_URL}/courses`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(courseData)
    });
    return res.json();
  },

  enrollCourse: async (courseId, traineeId) => {
    const res = await fetch(`${API_BASE_URL}/courses/${courseId}/enroll`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ traineeId })
    });
    return res.json();
  },

  uploadMaterial: async (courseId, subjectId, moduleId, materialData) => {
    const res = await fetch(`${API_BASE_URL}/courses/${courseId}/subjects/${subjectId}/modules/${moduleId}/materials`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(materialData)
    });
    return res.json();
  },

  submitFeedback: async (feedbackData) => {
    const res = await fetch(`${API_BASE_URL}/feedback`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(feedbackData)
    });
    return res.json();
  },

  getFeedbacks: async (courseId) => {
    const res = await fetch(`${API_BASE_URL}/feedback${courseId ? `?courseId=${courseId}` : ""}`);
    return res.json();
  },

  // Question Bank & Assessment Quizzes
  getQuestions: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE_URL}/questions${query ? `?${query}` : ""}`);
    return res.json();
  },

  createQuestion: async (questionData) => {
    const res = await fetch(`${API_BASE_URL}/questions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(questionData)
    });
    return res.json();
  },

  duplicateQuestion: async (id) => {
    const res = await fetch(`${API_BASE_URL}/questions/${id}/duplicate`, {
      method: "POST"
    });
    return res.json();
  },

  deleteQuestion: async (id) => {
    const res = await fetch(`${API_BASE_URL}/questions/${id}`, {
      method: "DELETE"
    });
    return res.json();
  },

  // AI Question Generator
  generateAiQuestions: async (payload) => {
    const res = await fetch(`${API_BASE_URL}/ai/generate-questions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  // Quizzes & Submissions
  getQuizzes: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE_URL}/quizzes${query ? `?${query}` : ""}`);
    return res.json();
  },

  getQuizById: async (id) => {
    const res = await fetch(`${API_BASE_URL}/quizzes/${id}`);
    return res.json();
  },

  createQuiz: async (quizData) => {
    const res = await fetch(`${API_BASE_URL}/quizzes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(quizData)
    });
    return res.json();
  },

  submitQuiz: async (submissionData) => {
    const res = await fetch(`${API_BASE_URL}/quizzes/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(submissionData)
    });
    return res.json();
  },

  getQuizAnalytics: async (quizId) => {
    const res = await fetch(`${API_BASE_URL}/quizzes/${quizId}/analytics`);
    return res.json();
  },

  getTraineeAnalytics: async (traineeId) => {
    const res = await fetch(`${API_BASE_URL}/analytics/trainee/${traineeId}`);
    return res.json();
  },

  // Competency Mapping
  getCompetencies: async () => {
    const res = await fetch(`${API_BASE_URL}/competencies`);
    return res.json();
  },

  suggestTrainers: async (subjectName, requiredSkills) => {
    const res = await fetch(`${API_BASE_URL}/competencies/suggest-trainers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subjectName, requiredSkills })
    });
    return res.json();
  },

  assignTrainerToCompetency: async (competencyId, trainerId, trainerName) => {
    const res = await fetch(`${API_BASE_URL}/competencies/${competencyId}/assign`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trainerId, trainerName })
    });
    return res.json();
  },

  // Admin Features
  getAdminStats: async () => {
    const res = await fetch(`${API_BASE_URL}/admin/stats`);
    return res.json();
  },

  getPendingUsers: async () => {
    const res = await fetch(`${API_BASE_URL}/admin/users/pending`);
    return res.json();
  },

  getAllUsers: async (params = {}) => {
    const query = new URLSearchParams(params).toString();
    const res = await fetch(`${API_BASE_URL}/admin/users${query ? `?${query}` : ""}`);
    return res.json();
  },

  verifyUser: async (id, approved, notes) => {
    const res = await fetch(`${API_BASE_URL}/admin/users/${id}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approved, notes })
    });
    return res.json();
  },

  getAnnouncements: async () => {
    const res = await fetch(`${API_BASE_URL}/announcements`);
    return res.json();
  },

  publishAnnouncement: async (annData) => {
    const res = await fetch(`${API_BASE_URL}/announcements`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(annData)
    });
    return res.json();
  }
};
