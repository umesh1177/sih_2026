import React, { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { Sidebar } from "./components/layout/Sidebar";
import { TopNavbar } from "./components/layout/TopNavbar";
import { QuestionBankTable } from "./components/quiz/QuestionBankTable";
import { KioskExamMode } from "./components/quiz/KioskExamMode";
import { AiQuestionModal } from "./components/quiz/AiQuestionModal";
import { QuizScheduleModal } from "./components/quiz/QuizScheduleModal";
import { QuizAnalyticsModal } from "./components/quiz/QuizAnalyticsModal";
import { CourseLearningStudio } from "./components/courses/CourseLearningStudio";
import { ProfessionalProfileModal } from "./components/profile/ProfessionalProfileModal";
import { CertificateModal } from "./components/profile/CertificateModal";
import { CompetencyMatrixView } from "./components/admin/CompetencyMatrixView";
import { UserApprovalQueue } from "./components/admin/UserApprovalQueue";
import { BroadcastManagerModal } from "./components/admin/BroadcastManagerModal";
import { TraineeDashboardView } from "./components/dashboard/TraineeDashboardView";
import { TrainerDashboardView } from "./components/dashboard/TrainerDashboardView";
import { AdminDashboardView } from "./components/dashboard/AdminDashboardView";
import { PublicHomePage } from "./pages/PublicHomePage";
import { api } from "./services/api";
import { 
  BookOpen, 
  Layers, 
  Award, 
  Sparkles, 
  Plus, 
  BarChart3, 
  ClipboardList, 
  BellRing,
  UserCheck,
  CheckCircle2,
  X,
  PlayCircle,
  FileText
} from "lucide-react";

const MainApp = () => {
  const { currentUser, switchAccount, demoAccounts } = useAuth();
  
  // Navigation & Page views
  const [viewMode, setViewMode] = useState("portal"); // "landing" | "portal"
  const [activeTab, setActiveTab] = useState("dashboard");

  // Full Tab Course Studio state (Replaces modal)
  const [activeStudioCourse, setActiveStudioCourse] = useState(null);

  // Active Modals & Fullscreen states
  const [activeExamQuiz, setActiveExamQuiz] = useState(null);
  const [selectedQuizAnalyticsId, setSelectedQuizAnalyticsId] = useState(null);
  const [certificateData, setCertificateData] = useState(null);
  
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [showAnnouncementsModal, setShowAnnouncementsModal] = useState(false);

  // Global Data
  const [courses, setCourses] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [announcements, setAnnouncements] = useState([]);

  const refreshGlobalData = async () => {
    try {
      const [cRes, qRes, aRes] = await Promise.all([
        api.getCourses(),
        api.getQuizzes(),
        api.getAnnouncements()
      ]);
      if (cRes.success) setCourses(cRes.courses);
      if (qRes.success) setQuizzes(qRes.quizzes);
      if (aRes.success) setAnnouncements(aRes.announcements);
    } catch (err) {
      console.error("Global data refresh failed:", err);
    }
  };

  useEffect(() => {
    refreshGlobalData();
  }, []);

  // Landing page view
  if (viewMode === "landing") {
    return (
      <PublicHomePage
        onEnterPortal={() => setViewMode("portal")}
        onOpenCourse={(c) => {
          setActiveStudioCourse(c);
          setViewMode("portal");
        }}
      />
    );
  }

  // If Full-Tab Course Studio is active -> Render full studio in the portal tab!
  if (activeStudioCourse) {
    return (
      <div className="flex h-screen bg-[#f8fafc] text-slate-800 font-sans overflow-hidden select-none">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveStudioCourse(null);
            setActiveTab(tab);
          }}
        />
        <div className="flex-1 flex flex-col h-screen overflow-hidden">
          <CourseLearningStudio
            course={activeStudioCourse}
            currentUser={currentUser}
            onBack={() => setActiveStudioCourse(null)}
            onEnrollSuccess={() => refreshGlobalData()}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#f8fafc] text-slate-800 font-sans overflow-hidden select-none">
      {/* Deep Navy Sidebar strictly matching Screenshots 1 & 3 */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Navbar */}
        <TopNavbar
          activeTab={activeTab}
          onOpenAnnouncements={() => setShowAnnouncementsModal(true)}
          onOpenAiGenerator={() => setIsAiModalOpen(true)}
        />

        {/* Dynamic Tab Pane */}
        <main className="flex-1 overflow-y-auto">
          {/* 1. DASHBOARD VIEW (Role specific) */}
          {activeTab === "dashboard" && (
            <>
              {currentUser?.role === "trainee" && (
                <TraineeDashboardView
                  currentUser={currentUser}
                  onStartExam={(q) => setActiveExamQuiz(q)}
                  onOpenCourse={(c) => setActiveStudioCourse(c)}
                  onOpenProfile={() => setIsProfileModalOpen(true)}
                  onOpenCertificate={(submission, courseTitle, traineeName) => {
                    setCertificateData({ submission, courseTitle, traineeName });
                  }}
                />
              )}

              {currentUser?.role === "trainer" && (
                <TrainerDashboardView
                  currentUser={currentUser}
                  onOpenQuestionBank={() => setActiveTab("questions")}
                  onOpenAiGenerator={() => setIsAiModalOpen(true)}
                  onOpenScheduleQuiz={() => setIsScheduleModalOpen(true)}
                  onOpenAnalytics={(qId) => setSelectedQuizAnalyticsId(qId)}
                  onOpenCourse={(c) => setActiveStudioCourse(c)}
                />
              )}

              {currentUser?.role === "admin" && (
                <AdminDashboardView
                  currentUser={currentUser}
                  onOpenApprovals={() => setActiveTab("approvals")}
                  onOpenCompetency={() => setActiveTab("competency")}
                  onOpenBroadcastModal={() => setIsBroadcastModalOpen(true)}
                  onOpenCreateCourse={() => setActiveStudioCourse(courses[0])}
                />
              )}
            </>
          )}

          {/* 2. QUESTION BANK (Matches Screenshot 1 & 3 UI) */}
          {activeTab === "questions" && (
            <QuestionBankTable
              onOpenAiGenerator={() => setIsAiModalOpen(true)}
            />
          )}

          {/* 3. ASSESSMENTS / QUIZZES LIST */}
          {(activeTab === "quizzes" || activeTab === "trainee-quizzes") && (
            <div className="p-6 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                    {currentUser?.role === "trainee" ? "Scheduled Proctored Assessments" : "Capacity Assessments Management"}
                  </h1>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Timed kiosk evaluations with automatic multi-chart analytics and anti-cheat proctoring.
                  </p>
                </div>

                {(currentUser?.role === "trainer" || currentUser?.role === "admin") && (
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={() => setIsAiModalOpen(true)}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl text-xs shadow-md"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                      <span>AI Generate Questions</span>
                    </button>
                    <button
                      onClick={() => setIsScheduleModalOpen(true)}
                      className="flex items-center gap-1.5 px-4 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl text-xs shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Schedule New Quiz</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {quizzes.map((quiz) => (
                  <div
                    key={quiz.id}
                    className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900">
                          {quiz.courseName || "IMD Course"}
                        </span>
                        <span className="text-xs font-semibold text-slate-500">
                          {quiz.durationMinutes} mins
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-900 text-sm mb-2">{quiz.title}</h3>
                      <p className="text-xs text-slate-500 mb-4">
                        Lead: <b>{quiz.trainerName}</b> • Pass: {quiz.passMarks}/{quiz.totalMarks} Marks
                      </p>
                    </div>

                    <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                      {currentUser?.role === "trainee" ? (
                        <button
                          onClick={() => setActiveExamQuiz(quiz)}
                          className="w-full py-2.5 bg-[#0a2558] hover:bg-[#071c42] text-white rounded-xl text-xs font-bold shadow-md transition-transform hover:scale-105"
                        >
                          Launch Kiosk Exam
                        </button>
                      ) : (
                        <button
                          onClick={() => setSelectedQuizAnalyticsId(quiz.id)}
                          className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-50 hover:bg-blue-100 text-[#0a2558] rounded-xl text-xs font-bold shadow-sm"
                        >
                          <BarChart3 className="w-4 h-4" />
                          <span>1-Click Result Analytics</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. COURSES & SUBJECTS CATALOG */}
          {(activeTab === "courses" || activeTab === "subjects" || activeTab === "my-learning") && (
            <div className="p-6 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                    Meteorological Training Curricula & Subject Library
                  </h1>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Click any course to open the full interactive Learning Studio with modules, videos, and study decks.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {courses.map(course => (
                  <div
                    key={course.id}
                    className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col justify-between group"
                  >
                    <div>
                      <div className="h-44 relative overflow-hidden">
                        <img 
                          src={course.thumbnail} 
                          alt={course.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                        />
                        <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#0a2558] text-white shadow">
                          {course.code}
                        </span>
                      </div>

                      <div className="p-5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">{course.category}</span>
                        <h3 className="font-bold text-slate-900 text-sm mt-1 mb-2 line-clamp-2 leading-snug">{course.title}</h3>
                        <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{course.description}</p>
                      </div>
                    </div>

                    <div className="p-5 pt-0 border-t border-slate-100 flex items-center justify-between mt-auto">
                      <span className="text-[11px] text-slate-500 font-medium">
                        {course.subjects?.length || 2} Subjects
                      </span>
                      <button
                        onClick={() => setActiveStudioCourse(course)}
                        className="px-4 py-2 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl text-xs shadow-md transition-transform hover:scale-105"
                      >
                        Open Learning Studio
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. COMPETENCY MAPPING */}
          {activeTab === "competency" && <CompetencyMatrixView />}

          {/* 6. USER APPROVALS */}
          {activeTab === "approvals" && <UserApprovalQueue />}

          {/* 7. CERTIFICATIONS SHOWCASE */}
          {activeTab === "certificates" && (
            <div className="p-6 space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                <h1 className="text-xl font-bold text-slate-900">Official MoES Verified Credentials</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Cryptographically registered capacity certifications with instant print and verification.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 bg-white rounded-3xl border-2 border-amber-300 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full">
                        DISTINCTION (100%)
                      </span>
                      <Award className="w-6 h-6 text-amber-500" />
                    </div>
                    <h3 className="font-bold text-slate-900 text-base mb-1">
                      Advanced Numerical Weather Prediction (NWP) & Data Assimilation
                    </h3>
                    <p className="text-xs text-slate-500">Certificate ID: MOES-IMD-CERT-2025-0981</p>
                  </div>
                  <button
                    onClick={() => {
                      setCertificateData({
                        courseTitle: "Advanced Numerical Weather Prediction (NWP)",
                        traineeName: currentUser?.name || "Rahul Sharma",
                        submission: {
                          certificateId: "MOES-IMD-CERT-2025-0981",
                          percentage: 100,
                          submittedAt: new Date().toISOString()
                        }
                      });
                    }}
                    className="mt-6 w-full py-2.5 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    View Official Printable Certificate
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 8. PROFILE VIEW */}
          {activeTab === "profile" && (
            <div className="p-6">
              <div className="max-w-2xl mx-auto bg-white rounded-3xl p-8 border border-slate-200 shadow-sm text-center">
                <img
                  src={currentUser?.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250"}
                  alt={currentUser?.name}
                  className="w-24 h-24 rounded-3xl mx-auto object-cover ring-4 ring-[#0a2558]/10 shadow-lg mb-4"
                />
                <h2 className="text-xl font-bold text-slate-900">{currentUser?.name}</h2>
                <p className="text-xs text-slate-500">{currentUser?.designation} • {currentUser?.department}</p>
                <div className="mt-4">
                  <button
                    onClick={() => setIsProfileModalOpen(true)}
                    className="px-6 py-2.5 bg-[#0a2558] hover:bg-[#071c42] text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    Edit & Submit Profile for Verification
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* FULLSCREEN KIOSK EXAM OVERLAY strictly matching Screenshot 2 */}
      {activeExamQuiz && (
        <KioskExamMode
          quiz={activeExamQuiz}
          currentUser={currentUser}
          onClose={() => setActiveExamQuiz(null)}
          onFinish={() => {
            refreshGlobalData();
            setActiveExamQuiz(null);
          }}
        />
      )}

      {/* Modals */}
      <AiQuestionModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        onQuestionsGenerated={() => {
          refreshGlobalData();
          setActiveTab("questions");
        }}
      />

      <QuizScheduleModal
        isOpen={isScheduleModalOpen}
        currentUser={currentUser}
        onClose={() => setIsScheduleModalOpen(false)}
        onQuizCreated={() => refreshGlobalData()}
      />

      <QuizAnalyticsModal
        isOpen={!!selectedQuizAnalyticsId}
        quizId={selectedQuizAnalyticsId}
        onClose={() => setSelectedQuizAnalyticsId(null)}
      />

      <ProfessionalProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      <CertificateModal
        isOpen={!!certificateData}
        submission={certificateData?.submission}
        courseTitle={certificateData?.courseTitle}
        traineeName={certificateData?.traineeName}
        onClose={() => setCertificateData(null)}
      />

      <BroadcastManagerModal
        isOpen={isBroadcastModalOpen}
        onClose={() => setIsBroadcastModalOpen(false)}
        onPublished={() => refreshGlobalData()}
      />

      {/* Announcements Modal */}
      {showAnnouncementsModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Active MoES Directives & Circulars</h2>
              <button onClick={() => setShowAnnouncementsModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1 text-xs">
              {announcements.map((a, i) => (
                <div key={i} className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">{a.title}</span>
                    <span className="text-[10px] text-slate-400">{a.date}</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">{a.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
